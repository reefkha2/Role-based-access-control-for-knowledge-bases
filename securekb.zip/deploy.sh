#!/bin/bash

# Deployment script for SecureKB

echo "Deploying SecureKB to AWS..."

# Activate virtual environment if it exists
if [ -d ".venv" ]; then
    source .venv/bin/activate
    echo "Activated virtual environment"
fi

# Install dependencies
pip install -r requirements.txt

# Change to the CDK directory
cd src/cdk

# Install CDK dependencies
npm install -g aws-cdk
pip install -r requirements.txt

# Bootstrap CDK (if needed)
cdk bootstrap

# Deploy the stack
cdk deploy --require-approval never

# Get the outputs
echo "Deployment completed. Stack outputs:"
aws cloudformation describe-stacks --stack-name SecureKbStack --query "Stacks[0].Outputs" --output table

# Save the outputs to a file for integration testing
aws cloudformation describe-stacks --stack-name SecureKbStack --query "Stacks[0].Outputs" --output json > ../../stack_outputs.json

# Create integration test config
cd ../..
python -c "
import json
with open('stack_outputs.json', 'r') as f:
    outputs = json.load(f)
config = {}
for output in outputs:
    key = output['OutputKey']
    value = output['OutputValue']
    if key == 'DocumentBucketName':
        config['document_bucket'] = value
    elif key == 'ProcessedChunksBucketName':
        config['processed_chunks_bucket'] = value
    elif key == 'UserPoolId':
        config['user_pool_id'] = value
    elif key == 'UserPoolClientId':
        config['user_pool_client_id'] = value
    elif key == 'ApiUrl':
        config['api_url'] = value
    elif key == 'KnowledgeBaseId':
        config['knowledge_base_id'] = value
with open('integration_test_config.json', 'w') as f:
    json.dump(config, f, indent=2)
print('Created integration_test_config.json')
"

echo "Deployment completed successfully!"
