#!/usr/bin/env python3

import http.server
import socketserver
import os
import sys
import webbrowser

def start_server(port=8000):
    """Start a simple HTTP server for the web interface"""
    try:
        # Change to the web directory
        os.chdir(os.path.dirname(os.path.abspath(__file__)))
        
        # Update config
        print("Updating configuration...")
        os.system("python update_config.py")
        
        # Start server
        handler = http.server.SimpleHTTPRequestHandler
        
        with socketserver.TCPServer(("", port), handler) as httpd:
            print(f"Server started at http://localhost:{port}")
            print("Press Ctrl+C to stop the server.")
            
            # Open browser
            webbrowser.open(f"http://localhost:{port}")
            
            # Serve until interrupted
            httpd.serve_forever()
    
    except KeyboardInterrupt:
        print("\nServer stopped.")
    except Exception as e:
        print(f"Error starting server: {e}")
        sys.exit(1)

if __name__ == "__main__":
    start_server()
