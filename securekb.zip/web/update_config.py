#!/usr/bin/env python3

import json
import os
import sys

def update_config():
    """Update the web config.json file with values from securekb_config.json"""
    try:
        # Check if securekb_config.json exists
        if not os.path.exists('../securekb_config.json'):
            print("Error: securekb_config.json not found.")
            sys.exit(1)
        
        # Load securekb_config.json
        with open('../securekb_config.json', 'r') as f:
            securekb_config = json.load(f)
        
        # Create web config
        web_config = {
            "api_url": securekb_config.get('api_url', ''),
            "processed_chunks_bucket": securekb_config.get('processed_chunks_bucket', '')
        }
        
        # Save web config.json
        with open('config.json', 'w') as f:
            json.dump(web_config, f, indent=2)
        
        print("Web config.json updated successfully.")
        return True
    
    except Exception as e:
        print(f"Error updating web config.json: {e}")
        return False

if __name__ == "__main__":
    update_config()
