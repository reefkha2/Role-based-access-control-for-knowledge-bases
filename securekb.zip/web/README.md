# SecureKB Web Interface

This is a simple web interface for demonstrating the SecureKB solution. It allows you to:

1. Select a user role (department and clearance level)
2. Enter a query or select a sample query
3. View the results based on the user's access level

## Getting Started

To start the web interface, run the following command:

```bash
python start_server.py
```

This will:
1. Update the configuration file with the latest values from `securekb_config.json`
2. Start a simple HTTP server on port 8000
3. Open your default web browser to the web interface

## Using the Web Interface

1. Select a department from the dropdown menu
2. Select a clearance level from the dropdown menu
3. Enter a query or select a sample query from the dropdown menu
4. Click the "Submit Query" button
5. View the results based on the user's access level

## Sample Queries

- "What are our sales numbers?"
- "What are our HR policies?"
- "What are our financial projections?"
- "What are our acquisition plans?"
- "What products do we offer?"

## Testing Different Access Levels

Try running the same query with different user roles to see how the results change based on the user's access level.

For example:
1. Run "What are our acquisition plans?" with a Sales user (department: sales, clearance: internal)
2. Run "What are our acquisition plans?" with an Executive user (department: executive, clearance: restricted)

You should see different results based on the user's access level.
