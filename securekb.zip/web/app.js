document.addEventListener('DOMContentLoaded', function() {
    const queryForm = document.getElementById('queryForm');
    const sampleQueries = document.getElementById('sampleQueries');
    const queryInput = document.getElementById('query');
    const resultCard = document.getElementById('resultCard');
    const userRole = document.getElementById('userRole');
    const userQuery = document.getElementById('userQuery');
    const resultContent = document.getElementById('resultContent');
    const loading = document.querySelector('.loading');

    // Access control messages for specific queries
    const accessControlMessages = {
        "acquisition": {
            "departments": ["executive", "finance"],
            "clearance": "restricted",
            "message": "I'm sorry, but you don't have access to information about acquisition plans. This information is only accessible to executive and finance departments with a restricted clearance level."
        },
        "financial": {
            "departments": ["finance", "executive"],
            "clearance": "confidential",
            "message": "I'm sorry, but you don't have access to detailed financial projections. This information is only accessible to finance and executive departments with a confidential clearance level."
        },
        "hr policies": {
            "departments": ["hr", "executive"],
            "clearance": "confidential",
            "message": "I'm sorry, but you don't have access to detailed HR policies. This information is only accessible to HR and executive departments with a confidential clearance level."
        },
        "strategy": {
            "departments": ["executive"],
            "clearance": "restricted",
            "message": "I'm sorry, but you don't have access to strategic planning information. This information is only accessible to the executive department with a restricted clearance level."
        }
    };

    // Load configuration
    let config = {};
    fetch('config.json')
        .then(response => response.json())
        .then(data => {
            config = data;
            console.log('Configuration loaded:', config);
        })
        .catch(error => {
            console.error('Error loading configuration:', error);
            alert('Failed to load configuration. Please check the console for details.');
        });

    // Handle sample query selection
    sampleQueries.addEventListener('change', function() {
        if (this.value) {
            queryInput.value = this.value;
        }
    });

    // Check if user has access to the requested information
    function checkAccessControl(query, department, clearance) {
        const queryLower = query.toLowerCase();
        
        // Check if query contains any restricted topics
        for (const [topic, access] of Object.entries(accessControlMessages)) {
            if (queryLower.includes(topic)) {
                // Check if user has required department
                const hasDepartment = access.departments.includes(department);
                
                // Check if user has required clearance
                const clearanceLevels = {
                    "public": 0,
                    "internal": 1,
                    "confidential": 2,
                    "restricted": 3
                };
                
                const userClearanceLevel = clearanceLevels[clearance] || 0;
                const requiredClearanceLevel = clearanceLevels[access.clearance] || 3;
                
                const hasClearance = userClearanceLevel >= requiredClearanceLevel;
                
                // If user doesn't have access, return the message
                if (!hasDepartment || !hasClearance) {
                    return access.message;
                }
            }
        }
        
        // User has access
        return null;
    }

    // Handle form submission
    queryForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const department = document.getElementById('department').value;
        const clearance = document.getElementById('clearance').value;
        const query = queryInput.value;
        
        if (!query) {
            alert('Please enter a query');
            return;
        }
        
        // Show loading indicator
        loading.style.display = 'block';
        resultCard.style.display = 'none';
        
        // Prepare user info
        const userInfo = {
            departments: [department],
            clearance_level: clearance
        };
        
        // Update user role display
        userRole.innerHTML = `Department: <span class="badge bg-primary">${department}</span> | Clearance: <span class="badge bg-secondary">${clearance}</span>`;
        userQuery.textContent = query;
        
        // Check access control
        const accessMessage = checkAccessControl(query, department, clearance);
        
        if (accessMessage) {
            // Hide loading indicator
            loading.style.display = 'none';
            
            // Display access control message
            resultContent.innerHTML = `
                <div class="alert alert-warning">
                    <strong>Access Denied</strong>
                </div>
                <h5>Response:</h5>
                <pre>${accessMessage}</pre>
            `;
            
            // Show result card
            resultCard.style.display = 'block';
            return;
        }
        
        // Make API request
        fetch(`${config.api_url}/query`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                query: query,
                user_info: userInfo,
                bucket_name: config.processed_chunks_bucket
            })
        })
        .then(response => response.json())
        .then(data => {
            // Hide loading indicator
            loading.style.display = 'none';
            
            // Display results
            if (data.status === 'success') {
                resultContent.innerHTML = `
                    <div class="alert alert-success">
                        <strong>Success!</strong> Query processed successfully.
                        ${data.num_chunks_used ? `<br><small>Chunks used: ${data.num_chunks_used}</small>` : ''}
                    </div>
                    <h5>Answer:</h5>
                    <pre>${data.answer}</pre>
                `;
            } else {
                resultContent.innerHTML = `
                    <div class="alert alert-danger">
                        <strong>Error!</strong> ${data.error || 'An unknown error occurred'}
                    </div>
                `;
            }
            
            // Show result card
            resultCard.style.display = 'block';
        })
        .catch(error => {
            // Hide loading indicator
            loading.style.display = 'none';
            
            // Display error
            resultContent.innerHTML = `
                <div class="alert alert-danger">
                    <strong>Error!</strong> Failed to connect to the API. Please check the console for details.
                </div>
            `;
            console.error('Error:', error);
            
            // Show result card
            resultCard.style.display = 'block';
        });
    });
});
