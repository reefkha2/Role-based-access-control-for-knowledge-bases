import boto3
import json
import os
import time
import unittest
import uuid

class TestEndToEndFlow(unittest.TestCase):
    """Integration tests for the complete SecureKB flow"""
    
    @classmethod
    def setUpClass(cls):
        """Set up resources for the integration tests"""
        # Load configuration
        try:
            with open('integration_test_config.json', 'r') as f:
                cls.config = json.load(f)
        except FileNotFoundError:
            cls.config = {
                "document_bucket": os.environ.get("DOCUMENT_BUCKET", ""),
                "processed_chunks_bucket": os.environ.get("PROCESSED_CHUNKS_BUCKET", ""),
                "knowledge_base_id": os.environ.get("KNOWLEDGE_BASE_ID", ""),
                "user_pool_id": os.environ.get("USER_POOL_ID", ""),
                "user_pool_client_id": os.environ.get("USER_POOL_CLIENT_ID", ""),
                "api_url": os.environ.get("API_URL", "")
            }
        
        # Initialize clients
        cls.s3 = boto3.client('s3')
        cls.lambda_client = boto3.client('lambda')
        cls.cognito = boto3.client('cognito-idp')
        cls.bedrock_agent_runtime = boto3.client('bedrock-agent-runtime')
        
        # Create test users if they don't exist
        cls.test_users = cls._create_test_users()
        
        # Upload test documents
        cls.test_documents = cls._upload_test_documents()
    
    @classmethod
    def _create_test_users(cls):
        """Create test users with different roles"""
        test_users = []
        
        # Define test users
        user_definitions = [
            {
                "username": f"sales-test-{int(time.time())}",
                "password": f"Test@password{uuid.uuid4().hex[:8]}",
                "department": "sales",
                "clearance_level": "internal"
            },
            {
                "username": f"hr-test-{int(time.time())}",
                "password": f"Test@password{uuid.uuid4().hex[:8]}",
                "department": "hr",
                "clearance_level": "internal"
            },
            {
                "username": f"finance-test-{int(time.time())}",
                "password": f"Test@password{uuid.uuid4().hex[:8]}",
                "department": "finance",
                "clearance_level": "confidential"
            },
            {
                "username": f"executive-test-{int(time.time())}",
                "password": f"Test@password{uuid.uuid4().hex[:8]}",
                "department": "executive",
                "clearance_level": "restricted"
            }
        ]
        
        # Create users in Cognito
        for user in user_definitions:
            try:
                # Create the user
                cls.cognito.admin_create_user(
                    UserPoolId=cls.config['user_pool_id'],
                    Username=user['username'],
                    TemporaryPassword=user['password'],
                    UserAttributes=[
                        {"Name": "email", "Value": f"{user['username']}@example.com"},
                        {"Name": "email_verified", "Value": "true"},
                        {"Name": "custom:department", "Value": user['department']},
                        {"Name": "custom:clearanceLevel", "Value": user['clearance_level']}
                    ],
                    MessageAction="SUPPRESS"
                )
                
                # Set permanent password
                cls.cognito.admin_set_user_password(
                    UserPoolId=cls.config['user_pool_id'],
                    Username=user['username'],
                    Password=user['password'],
                    Permanent=True
                )
                
                test_users.append(user)
                print(f"Created test user: {user['username']}")
            
            except Exception as e:
                print(f"Error creating test user {user['username']}: {e}")
        
        return test_users
    
    @classmethod
    def _upload_test_documents(cls):
        """Upload test documents to S3"""
        test_documents = []
        
        # Define test documents
        document_paths = [
            "sample_documents/sales_report.txt",
            "sample_documents/hr_policies.txt",
            "sample_documents/financial_report.txt",
            "sample_documents/executive_strategy.txt",
            "sample_documents/public_announcement.txt"
        ]
        
        # Upload documents to S3
        for path in document_paths:
            try:
                if os.path.exists(path):
                    # Generate a unique key for the document
                    key = f"test-documents/{os.path.basename(path)}"
                    
                    # Upload the document to S3
                    with open(path, 'rb') as f:
                        cls.s3.put_object(
                            Bucket=cls.config['document_bucket'],
                            Key=key,
                            Body=f.read()
                        )
                    
                    test_documents.append({
                        "path": path,
                        "key": key
                    })
                    print(f"Uploaded test document: {path} to s3://{cls.config['document_bucket']}/{key}")
            
            except Exception as e:
                print(f"Error uploading test document {path}: {e}")
        
        return test_documents
    
    def test_1_document_processing(self):
        """Test document processing and chunking"""
        if not self.test_documents:
            self.skipTest("No test documents available")
        
        # Process each test document
        for document in self.test_documents:
            # Invoke the document processor Lambda
            response = self.lambda_client.invoke(
                FunctionName="SecureKbStack-DocumentProcessor",
                InvocationType="RequestResponse",
                Payload=json.dumps({
                    "bucket": self.config['document_bucket'],
                    "key": document['key']
                })
            )
            
            # Parse the response
            payload = json.loads(response['Payload'].read().decode())
            
            # Check that the document was processed successfully
            self.assertEqual(payload['status'], 'success')
            self.assertEqual(payload['document'], f"s3://{self.config['document_bucket']}/{document['key']}")
            self.assertTrue(len(payload['chunks']) > 0)
            
            # Store the chunks for later tests
            document['chunks'] = payload['chunks']
            
            print(f"Document {document['path']} processed into {len(document['chunks'])} chunks")
    
    def test_2_metadata_tagging(self):
        """Test metadata tagging of chunks"""
        if not self.test_documents:
            self.skipTest("No test documents available")
        
        # Process chunks for each document
        for document in self.test_documents:
            if 'chunks' not in document:
                continue
            
            # Invoke the metadata tagger Lambda for each chunk
            for chunk in document['chunks']:
                response = self.lambda_client.invoke(
                    FunctionName="SecureKbStack-MetadataTagger",
                    InvocationType="RequestResponse",
                    Payload=json.dumps({
                        "chunk_key": chunk['chunk_key']
                    })
                )
                
                # Parse the response
                payload = json.loads(response['Payload'].read().decode())
                
                # Check that the chunk was tagged successfully
                self.assertEqual(payload['status'], 'success')
                self.assertEqual(payload['chunk_id'], chunk['chunk_id'])
                self.assertIn('metadata', payload)
                self.assertIn('departments', payload['metadata'])
                self.assertIn('sensitivity', payload['metadata'])
                
                # Store the metadata for later tests
                chunk['metadata'] = payload['metadata']
                
                print(f"Chunk {chunk['chunk_id']} tagged with departments: {payload['metadata']['departments']}, sensitivity: {payload['metadata']['sensitivity']}")
    
    def test_3_query_processing(self):
        """Test query processing with role-based filtering"""
        if not self.test_users:
            self.skipTest("No test users available")
        
        # Test queries for each user role
        test_queries = {
            "sales": "What are our sales targets for this quarter?",
            "hr": "What are our leave policies?",
            "finance": "What is our current financial performance?",
            "executive": "What is our strategic plan?"
        }
        
        for user in self.test_users:
            # Get the query for this user's department
            query = test_queries.get(user['department'], "What is the company's public information?")
            
            # Authenticate the user
            auth_response = self.cognito.initiate_auth(
                AuthFlow='USER_PASSWORD_AUTH',
                ClientId=self.config['user_pool_client_id'],
                AuthParameters={
                    'USERNAME': user['username'],
                    'PASSWORD': user['password']
                }
            )
            
            # Get the ID token
            id_token = auth_response['AuthenticationResult']['IdToken']
            
            # Invoke the query processor Lambda
            response = self.lambda_client.invoke(
                FunctionName="SecureKbStack-QueryProcessor",
                InvocationType="RequestResponse",
                Payload=json.dumps({
                    "query": query,
                    "knowledge_base_id": self.config['knowledge_base_id'],
                    "user_info": {
                        "departments": [user['department']],
                        "clearance_level": user['clearance_level']
                    }
                })
            )
            
            # Parse the response
            payload = json.loads(response['Payload'].read().decode())
            
            # Check that the query was processed successfully
            self.assertEqual(payload['statusCode'], 200)
            
            # Parse the body
            body = json.loads(payload['body'])
            self.assertEqual(body['status'], 'success')
            
            # Check that the results match the user's role
            if 'results' in body and body['results']:
                for result in body['results']:
                    if 'metadata' in result and 'departments' in result['metadata']:
                        # Check that the result is accessible to the user's department
                        self.assertTrue(
                            user['department'] in result['metadata']['departments'] or
                            'public' in result['metadata']['departments']
                        )
                    
                    if 'metadata' in result and 'sensitivity' in result['metadata']:
                        # Check that the result's sensitivity level is appropriate for the user
                        sensitivity_levels = {
                            'public': ['public'],
                            'internal': ['public', 'internal'],
                            'confidential': ['public', 'internal', 'confidential'],
                            'restricted': ['public', 'internal', 'confidential', 'restricted']
                        }
                        
                        allowed_levels = sensitivity_levels.get(user['clearance_level'], ['public'])
                        self.assertIn(result['metadata']['sensitivity'], allowed_levels)
            
            print(f"User {user['username']} ({user['department']}, {user['clearance_level']}) received {len(body.get('results', []))} results for query: {query}")
    
    @classmethod
    def tearDownClass(cls):
        """Clean up resources after the tests"""
        # In a real implementation, we would clean up the test users and documents
        # For this demo, we'll leave them for inspection
        pass

if __name__ == '__main__':
    unittest.main()
