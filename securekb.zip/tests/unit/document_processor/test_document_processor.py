import json
import os
import sys
import unittest
from unittest.mock import patch, MagicMock

# Add the Lambda function directory to the Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '../../../src/lambda/document_processor'))

import index

class TestDocumentProcessor(unittest.TestCase):
    
    def setUp(self):
        # Set up environment variables
        os.environ['PROCESSED_CHUNKS_BUCKET'] = 'test-processed-chunks-bucket'
    
    @patch('index.s3')
    def test_extract_text_from_document(self, mock_s3):
        # Mock the S3 get_object response
        mock_s3.get_object.return_value = {
            'Body': MagicMock(read=lambda: b'This is a test document content')
        }
        
        # Test with a text file
        result = index.extract_text_from_document('test-bucket', 'test-document.txt')
        self.assertEqual(result, 'This is a test document content')
        mock_s3.get_object.assert_called_with(Bucket='test-bucket', Key='test-document.txt')
    
    def test_chunk_document(self):
        # Test with a short document (should be a single chunk)
        short_text = "This is a short document."
        chunks = index.chunk_document(short_text, max_chunk_size=100)
        self.assertEqual(len(chunks), 1)
        self.assertEqual(chunks[0], short_text)
        
        # Test with a longer document that needs chunking
        long_text = "This is paragraph 1.\n\nThis is paragraph 2.\n\nThis is paragraph 3.\n\nThis is paragraph 4."
        chunks = index.chunk_document(long_text, max_chunk_size=20, overlap=5)
        self.assertTrue(len(chunks) > 1)
        
        # Check that all content is preserved across chunks
        combined = ""
        for chunk in chunks:
            combined += chunk
        
        # The combined chunks might have some overlap, so we check that all original paragraphs are present
        for paragraph in ["This is paragraph 1.", "This is paragraph 2.", "This is paragraph 3.", "This is paragraph 4."]:
            self.assertIn(paragraph, combined)
    
    @patch('index.s3')
    def test_process_document(self, mock_s3):
        # Mock the extract_text_from_document function
        with patch('index.extract_text_from_document') as mock_extract:
            mock_extract.return_value = "This is paragraph 1.\n\nThis is paragraph 2."
            
            # Mock the S3 put_object method
            mock_s3.put_object.return_value = {}
            
            # Test processing a document
            result = index.process_document('test-bucket', 'test-document.txt')
            
            # Check that the function returns success
            self.assertEqual(result['status'], 'success')
            self.assertEqual(result['document'], 's3://test-bucket/test-document.txt')
            self.assertTrue(len(result['chunks']) > 0)
            
            # Check that put_object was called for each chunk
            self.assertEqual(mock_s3.put_object.call_count, len(result['chunks']))
    
    @patch('index.process_document')
    def test_handler_s3_event(self, mock_process):
        # Mock the process_document function
        mock_process.return_value = {
            'status': 'success',
            'document': 's3://test-bucket/test-document.txt',
            'chunks': [{'chunk_id': 'test-chunk', 'chunk_key': 'chunks/test-chunk.json'}]
        }
        
        # Create a test S3 event
        s3_event = {
            'Records': [
                {
                    'eventSource': 'aws:s3',
                    's3': {
                        'bucket': {'name': 'test-bucket'},
                        'object': {'key': 'test-document.txt'}
                    }
                }
            ]
        }
        
        # Test the handler with an S3 event
        result = index.handler(s3_event, {})
        
        # Check that process_document was called with the correct arguments
        mock_process.assert_called_with('test-bucket', 'test-document.txt')
        
        # Check that the handler returns the result from process_document
        self.assertEqual(result['status'], 'success')
        self.assertEqual(result['document'], 's3://test-bucket/test-document.txt')
        self.assertEqual(len(result['chunks']), 1)
    
    @patch('index.process_document')
    def test_handler_direct_invocation(self, mock_process):
        # Mock the process_document function
        mock_process.return_value = {
            'status': 'success',
            'document': 's3://test-bucket/test-document.txt',
            'chunks': [{'chunk_id': 'test-chunk', 'chunk_key': 'chunks/test-chunk.json'}]
        }
        
        # Create a test direct invocation event
        direct_event = {
            'bucket': 'test-bucket',
            'key': 'test-document.txt'
        }
        
        # Test the handler with a direct invocation event
        result = index.handler(direct_event, {})
        
        # Check that process_document was called with the correct arguments
        mock_process.assert_called_with('test-bucket', 'test-document.txt')
        
        # Check that the handler returns the result from process_document
        self.assertEqual(result['status'], 'success')
        self.assertEqual(result['document'], 's3://test-bucket/test-document.txt')
        self.assertEqual(len(result['chunks']), 1)

if __name__ == '__main__':
    unittest.main()
