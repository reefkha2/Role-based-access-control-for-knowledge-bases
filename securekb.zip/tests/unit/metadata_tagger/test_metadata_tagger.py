import json
import os
import sys
import unittest
from unittest.mock import patch, MagicMock

# Add the Lambda function directory to the Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '../../../src/lambda/metadata_tagger'))

import index

class TestMetadataTagger(unittest.TestCase):
    
    def setUp(self):
        # Set up environment variables
        os.environ['PROCESSED_CHUNKS_BUCKET'] = 'test-processed-chunks-bucket'
    
    @patch('index.s3')
    def test_get_document_context(self, mock_s3):
        # Mock the S3 get_object response
        mock_s3.get_object.return_value = {
            'Body': MagicMock(read=lambda: b'This is a test document content')
        }
        
        # Test getting document context
        result = index.get_document_context('s3://test-bucket/test-document.txt')
        self.assertEqual(result, 'This is a test document content')
        mock_s3.get_object.assert_called_with(Bucket='test-bucket', Key='test-document.txt')
        
        # Test error handling
        mock_s3.get_object.side_effect = Exception("Test error")
        result = index.get_document_context('s3://test-bucket/test-document.txt')
        self.assertEqual(result, "")
    
    @patch('index.bedrock_runtime')
    def test_classify_chunk_with_llm(self, mock_bedrock):
        # Mock the Bedrock invoke_model response
        mock_response = {
            'body': MagicMock(read=lambda: json.dumps({
                'content': [{'text': '{"departments": ["sales"], "sensitivity": "internal"}'}]
            }).encode())
        }
        mock_bedrock.invoke_model.return_value = mock_response
        
        # Test classifying a chunk
        result = index.classify_chunk_with_llm("This is a sales document", "Sales context")
        self.assertEqual(result['departments'], ['sales'])
        self.assertEqual(result['sensitivity'], 'internal')
        
        # Test error handling
        mock_bedrock.invoke_model.side_effect = Exception("Test error")
        result = index.classify_chunk_with_llm("This is a sales document", "Sales context")
        self.assertEqual(result['departments'], ['public'])
        self.assertEqual(result['sensitivity'], 'public')
    
    @patch('index.s3')
    @patch('index.get_document_context')
    @patch('index.classify_chunk_with_llm')
    def test_process_chunk(self, mock_classify, mock_get_context, mock_s3):
        # Mock the S3 get_object response
        mock_s3.get_object.return_value = {
            'Body': MagicMock(read=lambda: json.dumps({
                'chunk_id': 'test-chunk',
                'content': 'This is a test chunk',
                'source_document': 's3://test-bucket/test-document.txt'
            }).encode())
        }
        
        # Mock the get_document_context function
        mock_get_context.return_value = "Document context"
        
        # Mock the classify_chunk_with_llm function
        mock_classify.return_value = {
            'departments': ['sales'],
            'sensitivity': 'internal'
        }
        
        # Test processing a chunk
        result = index.process_chunk('chunks/test-chunk.json')
        
        # Check that the function returns success
        self.assertEqual(result['status'], 'success')
        self.assertEqual(result['chunk_id'], 'test-chunk')
        self.assertEqual(result['metadata']['departments'], ['sales'])
        self.assertEqual(result['metadata']['sensitivity'], 'internal')
        
        # Check that S3 put_object was called with the updated chunk
        mock_s3.put_object.assert_called_once()
        args, kwargs = mock_s3.put_object.call_args
        self.assertEqual(kwargs['Bucket'], 'test-processed-chunks-bucket')
        self.assertEqual(kwargs['Key'], 'chunks/test-chunk.json')
        self.assertIn('Body', kwargs)
        
        # Test error handling
        mock_s3.get_object.side_effect = Exception("Test error")
        result = index.process_chunk('chunks/test-chunk.json')
        self.assertEqual(result['status'], 'error')
        self.assertEqual(result['chunk_key'], 'chunks/test-chunk.json')
    
    @patch('index.process_chunk')
    def test_handler_single_chunk(self, mock_process):
        # Mock the process_chunk function
        mock_process.return_value = {
            'status': 'success',
            'chunk_id': 'test-chunk',
            'metadata': {'departments': ['sales'], 'sensitivity': 'internal'}
        }
        
        # Create a test event for a single chunk
        event = {
            'chunk_key': 'chunks/test-chunk.json'
        }
        
        # Test the handler with a single chunk event
        result = index.handler(event, {})
        
        # Check that process_chunk was called with the correct arguments
        mock_process.assert_called_with('chunks/test-chunk.json')
        
        # Check that the handler returns the result from process_chunk
        self.assertEqual(result['status'], 'success')
        self.assertEqual(result['chunk_id'], 'test-chunk')
        self.assertEqual(result['metadata']['departments'], ['sales'])
        self.assertEqual(result['metadata']['sensitivity'], 'internal')
    
    @patch('index.process_chunk')
    def test_handler_multiple_chunks(self, mock_process):
        # Mock the process_chunk function
        mock_process.return_value = {
            'status': 'success',
            'chunk_id': 'test-chunk',
            'metadata': {'departments': ['sales'], 'sensitivity': 'internal'}
        }
        
        # Create a test event for multiple chunks
        event = {
            'chunks': [
                {'chunk_key': 'chunks/test-chunk-1.json'},
                {'chunk_key': 'chunks/test-chunk-2.json'}
            ]
        }
        
        # Test the handler with a multiple chunks event
        result = index.handler(event, {})
        
        # Check that process_chunk was called for each chunk
        self.assertEqual(mock_process.call_count, 2)
        mock_process.assert_any_call('chunks/test-chunk-1.json')
        mock_process.assert_any_call('chunks/test-chunk-2.json')
        
        # Check that the handler returns success and results for all chunks
        self.assertEqual(result['status'], 'success')
        self.assertEqual(len(result['results']), 2)

if __name__ == '__main__':
    unittest.main()
