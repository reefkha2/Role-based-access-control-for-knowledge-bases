import json
import os
import sys
import unittest
from unittest.mock import patch, MagicMock

# Add the Lambda function directory to the Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '../../../src/lambda/query_processor'))

import index

class TestQueryProcessor(unittest.TestCase):
    
    def setUp(self):
        # Set up environment variables
        os.environ['KNOWLEDGE_BASE_ID'] = 'test-knowledge-base-id'
    
    def test_extract_user_role_from_api_gateway_event(self):
        # Test extracting user role from API Gateway event
        event = {
            'body': json.dumps({
                'user_info': {
                    'departments': ['sales'],
                    'clearance_level': 'internal'
                }
            })
        }
        
        result = index.extract_user_role(event)
        self.assertEqual(result['departments'], ['sales'])
        self.assertEqual(result['clearance_level'], 'internal')
    
    def test_extract_user_role_from_direct_invocation(self):
        # Test extracting user role from direct invocation
        event = {
            'user_info': {
                'departments': ['hr'],
                'clearance_level': 'confidential'
            }
        }
        
        result = index.extract_user_role(event)
        self.assertEqual(result['departments'], ['hr'])
        self.assertEqual(result['clearance_level'], 'confidential')
    
    def test_extract_user_role_with_string_department(self):
        # Test extracting user role with department as string
        event = {
            'user_info': {
                'departments': 'finance',
                'clearance_level': 'restricted'
            }
        }
        
        result = index.extract_user_role(event)
        self.assertEqual(result['departments'], ['finance'])
        self.assertEqual(result['clearance_level'], 'restricted')
    
    def test_extract_user_role_with_missing_info(self):
        # Test extracting user role with missing information
        event = {}
        
        result = index.extract_user_role(event)
        self.assertEqual(result['departments'], ['public'])
        self.assertEqual(result['clearance_level'], 'public')
    
    def test_generate_filter_expression_single_department(self):
        # Test generating filter expression for a user with a single department
        user_role = {
            'departments': ['sales'],
            'clearance_level': 'internal'
        }
        
        result = index.generate_filter_expression(user_role)
        
        # Check that the filter has the correct structure
        self.assertIn('andAll', result)
        self.assertEqual(len(result['andAll']), 2)
        
        # Check department filter
        self.assertIn('listContains', result['andAll'][0])
        self.assertEqual(result['andAll'][0]['listContains']['key'], 'metadata.departments')
        self.assertEqual(result['andAll'][0]['listContains']['value'], 'sales')
        
        # Check sensitivity filter
        self.assertIn('in', result['andAll'][1])
        self.assertEqual(result['andAll'][1]['in']['key'], 'metadata.sensitivity')
        self.assertIn('public', result['andAll'][1]['in']['value'])
        self.assertIn('internal', result['andAll'][1]['in']['value'])
    
    def test_generate_filter_expression_multiple_departments(self):
        # Test generating filter expression for a user with multiple departments
        user_role = {
            'departments': ['sales', 'marketing'],
            'clearance_level': 'confidential'
        }
        
        result = index.generate_filter_expression(user_role)
        
        # Check that the filter has the correct structure
        self.assertIn('andAll', result)
        self.assertEqual(len(result['andAll']), 2)
        
        # Check department filter
        self.assertIn('orAll', result['andAll'][0])
        self.assertEqual(len(result['andAll'][0]['orAll']), 2)
        
        # Check first department
        self.assertIn('listContains', result['andAll'][0]['orAll'][0])
        self.assertEqual(result['andAll'][0]['orAll'][0]['listContains']['key'], 'metadata.departments')
        self.assertEqual(result['andAll'][0]['orAll'][0]['listContains']['value'], 'sales')
        
        # Check second department
        self.assertIn('listContains', result['andAll'][0]['orAll'][1])
        self.assertEqual(result['andAll'][0]['orAll'][1]['listContains']['key'], 'metadata.departments')
        self.assertEqual(result['andAll'][0]['orAll'][1]['listContains']['value'], 'marketing')
        
        # Check sensitivity filter
        self.assertIn('in', result['andAll'][1])
        self.assertEqual(result['andAll'][1]['in']['key'], 'metadata.sensitivity')
        self.assertIn('public', result['andAll'][1]['in']['value'])
        self.assertIn('internal', result['andAll'][1]['in']['value'])
        self.assertIn('confidential', result['andAll'][1]['in']['value'])
    
    def test_generate_filter_expression_error_handling(self):
        # Test error handling in filter generation
        with patch('index.logger') as mock_logger:
            # Create a user role that will cause an error
            user_role = None
            
            result = index.generate_filter_expression(user_role)
            
            # Check that an error was logged
            mock_logger.error.assert_called_once()
            
            # Check that a default filter was returned
            self.assertIn('equals', result)
            self.assertEqual(result['equals']['key'], 'metadata.sensitivity')
            self.assertEqual(result['equals']['value'], 'public')
    
    @patch('index.bedrock_agent_runtime')
    def test_query_knowledge_base(self, mock_bedrock_agent):
        # Mock the Bedrock Knowledge Base API response
        mock_bedrock_agent.retrieve.return_value = {
            'retrievalResults': [
                {
                    'content': {'text': 'This is a test result'},
                    'metadata': {'departments': ['sales'], 'sensitivity': 'internal'},
                    'location': {'type': 's3'},
                    'score': 0.95
                }
            ]
        }
        
        # Test querying the knowledge base
        filter_expression = {
            'listContains': {
                'key': 'metadata.departments',
                'value': 'sales'
            }
        }
        
        result = index.query_knowledge_base('test query', filter_expression, 'test-kb-id')
        
        # Check that the function returns success
        self.assertEqual(result['status'], 'success')
        self.assertEqual(len(result['results']), 1)
        self.assertEqual(result['results'][0]['content'], 'This is a test result')
        self.assertEqual(result['results'][0]['metadata']['departments'], ['sales'])
        self.assertEqual(result['results'][0]['metadata']['sensitivity'], 'internal')
        
        # Check that the Bedrock API was called with the correct arguments
        mock_bedrock_agent.retrieve.assert_called_with(
            knowledgeBaseId='test-kb-id',
            retrievalQuery={'text': 'test query'},
            retrievalConfiguration={
                'vectorSearchConfiguration': {
                    'filter': filter_expression,
                    'numberOfResults': 5
                }
            }
        )
        
        # Test error handling
        mock_bedrock_agent.retrieve.side_effect = Exception("Test error")
        result = index.query_knowledge_base('test query', filter_expression, 'test-kb-id')
        self.assertEqual(result['status'], 'error')
    
    @patch('index.cloudwatch')
    @patch('index.logger')
    def test_log_access(self, mock_logger, mock_cloudwatch):
        # Test logging access
        user_role = {
            'departments': ['sales'],
            'clearance_level': 'internal'
        }
        query_text = 'test query'
        filter_expression = {'test': 'filter'}
        results_count = 5
        
        index.log_access(user_role, query_text, filter_expression, results_count)
        
        # Check that logger was called
        mock_logger.info.assert_any_call(f"Access log: User with departments {user_role['departments']} and clearance {user_role['clearance_level']} queried: {query_text}")
        
        # Check that CloudWatch metrics were published
        mock_cloudwatch.put_metric_data.assert_called_once()
        args, kwargs = mock_cloudwatch.put_metric_data.call_args
        self.assertEqual(kwargs['Namespace'], 'SecureKB')
        self.assertEqual(len(kwargs['MetricData']), 2)
        
        # Check QueryCount metric
        self.assertEqual(kwargs['MetricData'][0]['MetricName'], 'QueryCount')
        self.assertEqual(kwargs['MetricData'][0]['Value'], 1)
        self.assertEqual(kwargs['MetricData'][0]['Dimensions'][0]['Name'], 'Department')
        self.assertEqual(kwargs['MetricData'][0]['Dimensions'][0]['Value'], 'sales')
        
        # Check ResultsCount metric
        self.assertEqual(kwargs['MetricData'][1]['MetricName'], 'ResultsCount')
        self.assertEqual(kwargs['MetricData'][1]['Value'], 5)
    
    @patch('index.extract_user_role')
    @patch('index.generate_filter_expression')
    @patch('index.query_knowledge_base')
    @patch('index.log_access')
    def test_handler(self, mock_log, mock_query, mock_filter, mock_extract):
        # Mock the extract_user_role function
        mock_extract.return_value = {
            'departments': ['sales'],
            'clearance_level': 'internal'
        }
        
        # Mock the generate_filter_expression function
        mock_filter.return_value = {'test': 'filter'}
        
        # Mock the query_knowledge_base function
        mock_query.return_value = {
            'status': 'success',
            'results': [{'content': 'test result'}]
        }
        
        # Create a test API Gateway event
        event = {
            'body': json.dumps({
                'query': 'test query',
                'knowledge_base_id': 'test-kb-id'
            })
        }
        
        # Test the handler
        result = index.handler(event, {})
        
        # Check that the handler returns a valid API Gateway response
        self.assertEqual(result['statusCode'], 200)
        self.assertEqual(result['headers']['Content-Type'], 'application/json')
        self.assertIn('body', result)
        
        # Parse the body
        body = json.loads(result['body'])
        self.assertEqual(body['status'], 'success')
        self.assertEqual(len(body['results']), 1)
        self.assertEqual(body['results'][0]['content'], 'test result')
        
        # Check that all the functions were called with the correct arguments
        mock_extract.assert_called_with(event)
        mock_filter.assert_called_with(mock_extract.return_value)
        mock_query.assert_called_with('test query', mock_filter.return_value, 'test-kb-id')
        mock_log.assert_called_with(
            mock_extract.return_value,
            'test query',
            mock_filter.return_value,
            1
        )

if __name__ == '__main__':
    unittest.main()
