#!/bin/bash

# SecureKB Demo Script

echo "===== SecureKB Demo ====="
echo ""

# Check if configuration exists
if [ ! -f "securekb_config.json" ]; then
    echo "Configuration file not found. Running deployment..."
    ./deploy_with_cli.sh
else
    echo "Using existing configuration."
fi

# Load configuration
DOCUMENT_BUCKET=$(jq -r '.document_bucket' securekb_config.json)
USER_POOL_ID=$(jq -r '.user_pool_id' securekb_config.json)
API_URL=$(jq -r '.api_url' securekb_config.json)

echo "Document Bucket: $DOCUMENT_BUCKET"
echo "User Pool ID: $USER_POOL_ID"
echo "API URL: $API_URL"
echo ""

# Upload sample documents
echo "===== Uploading Sample Documents ====="
python upload_sample_documents.py
echo ""

# Create test users
echo "===== Creating Test Users ====="
python create_test_users.py
echo ""

# Wait for document processing
echo "===== Waiting for document processing (30 seconds) ====="
sleep 30
echo ""

# Run queries with different user roles
echo "===== Running Queries with Different User Roles ====="
echo ""

echo "1. Sales User Query: What are our sales numbers?"
python test_query.py --department sales --clearance internal --query "What are our sales numbers?"
echo ""

echo "2. HR User Query: What are our HR policies?"
python test_query.py --department hr --clearance confidential --query "What are our HR policies?"
echo ""

echo "3. Finance User Query: What are our financial projections?"
python test_query.py --department finance --clearance confidential --query "What are our financial projections?"
echo ""

echo "4. Executive User Query: What are our acquisition plans?"
python test_query.py --department executive --clearance restricted --query "What are our acquisition plans?"
echo ""

echo "5. Public User Query: What products do we offer?"
python test_query.py --department public --clearance public --query "What products do we offer?"
echo ""

echo "===== Demo Complete ====="
