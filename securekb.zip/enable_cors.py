#!/usr/bin/env python3

import json
import boto3
import os
import sys

def enable_cors():
    """Enable CORS on the API Gateway"""
    try:
        # Check if config file exists
        if not os.path.exists('securekb_config.json'):
            print("Error: securekb_config.json not found.")
            sys.exit(1)
        
        # Load configuration
        with open('securekb_config.json', 'r') as f:
            config = json.load(f)
        
        # Extract API ID from the API URL
        api_url = config.get('api_url', '')
        if not api_url:
            print("Error: api_url not found in configuration.")
            sys.exit(1)
        
        api_id = api_url.split('/')[2].split('.')[0]
        print(f"API ID: {api_id}")
        
        # Create API Gateway client
        apigateway = boto3.client('apigateway')
        
        # Get resources
        resources = apigateway.get_resources(restApiId=api_id)
        
        # Find the query resource
        query_resource_id = None
        for resource in resources['items']:
            if resource.get('pathPart') == 'query':
                query_resource_id = resource['id']
                break
        
        if not query_resource_id:
            print("Error: query resource not found.")
            sys.exit(1)
        
        print(f"Query Resource ID: {query_resource_id}")
        
        # Enable CORS
        print("Enabling CORS...")
        
        # Add OPTIONS method
        try:
            apigateway.put_method(
                restApiId=api_id,
                resourceId=query_resource_id,
                httpMethod='OPTIONS',
                authorizationType='NONE'
            )
            print("Added OPTIONS method.")
        except Exception as e:
            print(f"OPTIONS method already exists or error: {e}")
        
        # Add OPTIONS method response
        try:
            apigateway.put_method_response(
                restApiId=api_id,
                resourceId=query_resource_id,
                httpMethod='OPTIONS',
                statusCode='200',
                responseParameters={
                    'method.response.header.Access-Control-Allow-Headers': True,
                    'method.response.header.Access-Control-Allow-Methods': True,
                    'method.response.header.Access-Control-Allow-Origin': True
                }
            )
            print("Added OPTIONS method response.")
        except Exception as e:
            print(f"OPTIONS method response already exists or error: {e}")
        
        # Add OPTIONS integration
        try:
            apigateway.put_integration(
                restApiId=api_id,
                resourceId=query_resource_id,
                httpMethod='OPTIONS',
                type='MOCK',
                requestTemplates={
                    'application/json': '{"statusCode": 200}'
                }
            )
            print("Added OPTIONS integration.")
        except Exception as e:
            print(f"OPTIONS integration already exists or error: {e}")
        
        # Add OPTIONS integration response
        try:
            apigateway.put_integration_response(
                restApiId=api_id,
                resourceId=query_resource_id,
                httpMethod='OPTIONS',
                statusCode='200',
                responseParameters={
                    'method.response.header.Access-Control-Allow-Headers': "'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token'",
                    'method.response.header.Access-Control-Allow-Methods': "'GET,POST,OPTIONS'",
                    'method.response.header.Access-Control-Allow-Origin': "'*'"
                }
            )
            print("Added OPTIONS integration response.")
        except Exception as e:
            print(f"OPTIONS integration response already exists or error: {e}")
        
        # Update POST method response
        try:
            apigateway.put_method_response(
                restApiId=api_id,
                resourceId=query_resource_id,
                httpMethod='POST',
                statusCode='200',
                responseParameters={
                    'method.response.header.Access-Control-Allow-Origin': True
                }
            )
            print("Updated POST method response.")
        except Exception as e:
            print(f"POST method response already exists or error: {e}")
        
        # Deploy API
        print("Deploying API...")
        apigateway.create_deployment(
            restApiId=api_id,
            stageName='prod'
        )
        
        print("CORS enabled successfully.")
        return True
    
    except Exception as e:
        print(f"Error enabling CORS: {e}")
        return False

if __name__ == "__main__":
    enable_cors()
