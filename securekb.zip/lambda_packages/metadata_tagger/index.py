import json
import boto3
import os
import time

# Initialize clients
s3 = boto3.client('s3')
bedrock_runtime = boto3.client('bedrock-runtime')
processed_chunks_bucket = os.environ.get('PROCESSED_CHUNKS_BUCKET')

def get_document_context(source_document):
    """Get the context from the source document"""
    try:
        # Parse the S3 URI
        uri_parts = source_document.replace("s3://", "").split("/", 1)
        bucket = uri_parts[0]
        key = uri_parts[1]
        
        # Get the document from S3
        response = s3.get_object(Bucket=bucket, Key=key)
        document_text = response['Body'].read().decode('utf-8')
        
        # For large documents, we might want to just return a summary or the first few paragraphs
        # For this demo, we'll return the first 1000 characters
        return document_text[:1000]
    
    except Exception as e:
        print(f"Error getting document context: {e}")
        return ""

def classify_chunk_with_llm(chunk_content, document_context):
    """Use Bedrock to classify the chunk content"""
    try:
        print(f"Classifying chunk with LLM. Chunk length: {len(chunk_content)}")
        
        prompt = f"""
        <document_context>
        {document_context}
        </document_context>
        
        <chunk_content>
        {chunk_content}
        </chunk_content>
        
        Based on the document context and chunk content above, please classify this chunk by:
        1. Department(s) that should have access (choose from: sales, hr, finance, executive, public)
        2. Sensitivity level (choose from: public, internal, confidential, restricted)
        
        Return your answer in JSON format like this:
        {{
          "departments": ["department1", "department2"],
          "sensitivity": "level"
        }}
        
        Answer only with the JSON and nothing else.
        """
        
        # Call Bedrock with Claude model
        response = bedrock_runtime.invoke_model(
            modelId='anthropic.claude-3-haiku-20240307-v1:0',
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 200,
                "messages": [
                    {"role": "user", "content": prompt}
                ]
            })
        )
        
        # Parse the response
        response_body = json.loads(response['body'].read())
        classification_text = response_body['content'][0]['text']
        
        # Parse the JSON response
        classification = json.loads(classification_text)
        
        print(f"Classification result: {classification}")
        return classification
    
    except Exception as e:
        print(f"Error classifying chunk with LLM: {e}")
        # Return a default classification
        return {
            "departments": ["public"],
            "sensitivity": "public"
        }

def process_chunk(chunk_key):
    """Process a chunk and add metadata"""
    try:
        # Get the chunk from S3
        response = s3.get_object(Bucket=processed_chunks_bucket, Key=chunk_key)
        chunk_data = json.loads(response['Body'].read().decode('utf-8'))
        
        # Get document context
        document_context = get_document_context(chunk_data['source_document'])
        
        # Classify the chunk
        classification = classify_chunk_with_llm(chunk_data['content'], document_context)
        
        # Add metadata to the chunk
        chunk_data['metadata'] = {
            "departments": classification['departments'],
            "sensitivity": classification['sensitivity'],
            "classified_at": time.time()
        }
        
        # Save the updated chunk back to S3
        s3.put_object(
            Bucket=processed_chunks_bucket,
            Key=chunk_key,
            Body=json.dumps(chunk_data),
            ContentType='application/json'
        )
        
        return {
            "status": "success",
            "chunk_id": chunk_data['chunk_id'],
            "metadata": chunk_data['metadata']
        }
    
    except Exception as e:
        print(f"Error processing chunk: {e}")
        return {
            "status": "error",
            "chunk_key": chunk_key,
            "error": str(e)
        }

def handler(event, context):
    """Lambda handler for metadata tagging"""
    print(f"Received event: {json.dumps(event)}")
    
    # Check if the event contains chunk information
    if 'chunk_key' in event:
        # Process a single chunk
        return process_chunk(event['chunk_key'])
    
    elif 'chunks' in event:
        # Process multiple chunks
        results = []
        for chunk in event['chunks']:
            result = process_chunk(chunk['chunk_key'])
            results.append(result)
        
        return {
            "status": "success",
            "results": results
        }
    
    else:
        return {
            "status": "error",
            "error": "Invalid event format"
        }
