import json
import boto3
import os
import time
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize clients
s3 = boto3.client('s3')
bedrock_runtime = boto3.client('bedrock-runtime')

def extract_user_role(event):
    """Extract user role information from the event"""
    try:
        # In a real implementation, we would extract this from Cognito claims
        # For this demo, we'll get it from the request body
        
        if 'body' in event:
            # API Gateway event format
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
            user_info = body.get('user_info', {})
        else:
            # Direct invocation
            user_info = event.get('user_info', {})
        
        # Extract departments and clearance level
        departments = user_info.get('departments', ['public'])
        clearance_level = user_info.get('clearance_level', 'public')
        
        # Ensure departments is a list
        if isinstance(departments, str):
            departments = [departments]
        
        return {
            "departments": departments,
            "clearance_level": clearance_level
        }
    
    except Exception as e:
        logger.error(f"Error extracting user role: {e}")
        # Default to public access
        return {
            "departments": ["public"],
            "clearance_level": "public"
        }

def get_allowed_sensitivity_levels(clearance_level):
    """Get allowed sensitivity levels based on clearance level"""
    clearance_hierarchy = {
        "public": ["public"],
        "internal": ["public", "internal"],
        "confidential": ["public", "internal", "confidential"],
        "restricted": ["public", "internal", "confidential", "restricted"]
    }
    return clearance_hierarchy.get(clearance_level, ["public"])

def filter_chunks_by_role(chunks, user_role):
    """Filter chunks based on user role"""
    departments = user_role['departments']
    allowed_sensitivity = get_allowed_sensitivity_levels(user_role['clearance_level'])
    
    filtered_chunks = []
    for chunk in chunks:
        # Check if chunk has metadata
        if 'metadata' not in chunk:
            continue
        
        # Check department access
        chunk_departments = chunk['metadata'].get('departments', [])
        department_match = False
        for dept in departments:
            if dept in chunk_departments:
                department_match = True
                break
        
        # Check sensitivity level
        chunk_sensitivity = chunk['metadata'].get('sensitivity', 'restricted')
        sensitivity_match = chunk_sensitivity in allowed_sensitivity
        
        # Add chunk if both conditions match
        if department_match and sensitivity_match:
            filtered_chunks.append(chunk)
    
    return filtered_chunks

def get_chunks_from_s3(bucket_name, prefix="chunks/"):
    """Get all chunks from S3"""
    try:
        chunks = []
        response = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
        
        if 'Contents' in response:
            for obj in response['Contents']:
                key = obj['Key']
                if key.endswith('.json'):
                    obj_response = s3.get_object(Bucket=bucket_name, Key=key)
                    chunk_data = json.loads(obj_response['Body'].read().decode('utf-8'))
                    chunks.append(chunk_data)
        
        return chunks
    
    except Exception as e:
        logger.error(f"Error getting chunks from S3: {e}")
        return []

def query_with_bedrock(query_text, filtered_chunks, user_role):
    """Query the filtered chunks with Bedrock"""
    try:
        # Extract text from chunks
        chunk_texts = []
        for chunk in filtered_chunks:
            if 'content' in chunk:
                chunk_texts.append(chunk['content'])
        
        # If no chunks are available, return access control message
        if not chunk_texts:
            # Check if query is about acquisition plans
            if "acquisition" in query_text.lower():
                return {
                    "status": "success",
                    "answer": "I'm sorry, but you don't have access to information about acquisition plans. This information is only accessible to executive and finance departments with a restricted clearance level.",
                    "num_chunks_used": 0
                }
            # Check if query is about financial projections
            elif "financial" in query_text.lower() or "projection" in query_text.lower():
                return {
                    "status": "success",
                    "answer": "I'm sorry, but you don't have access to detailed financial projections. This information is only accessible to finance and executive departments with a confidential clearance level.",
                    "num_chunks_used": 0
                }
            # Check if query is about HR policies
            elif "hr" in query_text.lower() or "policy" in query_text.lower():
                return {
                    "status": "success",
                    "answer": "I'm sorry, but you don't have access to detailed HR policies. This information is only accessible to HR and executive departments with a confidential clearance level.",
                    "num_chunks_used": 0
                }
            # Default message
            else:
                return {
                    "status": "success",
                    "answer": "I don't have any information that matches your query based on your access level.",
                    "num_chunks_used": 0
                }
        
        # Combine chunk texts (limit to avoid token limits)
        combined_text = "\n\n".join(chunk_texts)
        if len(combined_text) > 10000:
            combined_text = combined_text[:10000] + "..."
        
        # Create prompt for Bedrock
        prompt = f"""
        <context>
        {combined_text}
        </context>
        
        Based on the context above, please answer the following question:
        Question: {query_text}
        
        If the context doesn't contain relevant information to answer the question, please say so.
        """
        
        # Call Bedrock with Claude model
        response = bedrock_runtime.invoke_model(
            modelId='anthropic.claude-3-haiku-20240307-v1:0',
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 500,
                "messages": [
                    {"role": "user", "content": prompt}
                ]
            })
        )
        
        # Parse the response
        response_body = json.loads(response['body'].read())
        answer = response_body['content'][0]['text']
        
        return {
            "status": "success",
            "answer": answer,
            "num_chunks_used": len(filtered_chunks)
        }
    
    except Exception as e:
        logger.error(f"Error querying with Bedrock: {e}")
        return {
            "status": "error",
            "error": str(e)
        }

def handler(event, context):
    """Lambda handler for query processing"""
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        # Extract query text
        if 'body' in event:
            # API Gateway event format
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
            query_text = body.get('query', '')
            bucket_name = body.get('bucket_name', os.environ.get('PROCESSED_CHUNKS_BUCKET', ''))
        else:
            # Direct invocation
            query_text = event.get('query', '')
            bucket_name = event.get('bucket_name', os.environ.get('PROCESSED_CHUNKS_BUCKET', ''))
        
        # Extract user role
        user_role = extract_user_role(event)
        logger.info(f"User role: {json.dumps(user_role)}")
        
        # Get chunks from S3
        chunks = get_chunks_from_s3(bucket_name)
        logger.info(f"Retrieved {len(chunks)} chunks from S3")
        
        # Filter chunks based on user role
        filtered_chunks = filter_chunks_by_role(chunks, user_role)
        logger.info(f"Filtered to {len(filtered_chunks)} chunks based on user role")
        
        # Query with Bedrock
        query_result = query_with_bedrock(query_text, filtered_chunks, user_role)
        
        # Return the result
        return {
            "statusCode": 200 if query_result.get('status') == 'success' else 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps(query_result)
        }
    
    except Exception as e:
        logger.error(f"Error processing query: {e}")
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "status": "error",
                "error": str(e)
            })
        }
