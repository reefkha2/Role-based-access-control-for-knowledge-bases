import json
import boto3
import os
import uuid
import time
from urllib.parse import unquote_plus

# Initialize clients
s3 = boto3.client('s3')
processed_chunks_bucket = os.environ.get('PROCESSED_CHUNKS_BUCKET')

def extract_text_from_document(bucket, key):
    """Extract text from a document in S3"""
    print(f"Extracting text from document: s3://{bucket}/{key}")
    
    # Get the file extension
    _, file_extension = os.path.splitext(key.lower())
    
    # Get the object from S3
    response = s3.get_object(Bucket=bucket, Key=key)
    content = response['Body'].read()
    
    # For this demo, we'll just handle text files
    # In a real implementation, we would use libraries like PyPDF2, docx, etc.
    if file_extension in ['.txt', '.md', '.json']:
        return content.decode('utf-8')
    else:
        # For demo purposes, just return the first 1000 bytes as text
        # In a real implementation, we would use appropriate libraries for each file type
        print(f"Warning: Unsupported file type {file_extension}. Treating as plain text.")
        return content.decode('utf-8', errors='ignore')[:1000]

def chunk_document(text, max_chunk_size=1000, overlap=100):
    """Split document text into chunks with overlap"""
    print(f"Chunking document of length {len(text)} with max chunk size {max_chunk_size}")
    
    # If text is shorter than max_chunk_size, return it as a single chunk
    if len(text) <= max_chunk_size:
        return [text]
    
    chunks = []
    start = 0
    
    while start < len(text):
        # Find the end of the chunk
        end = start + max_chunk_size
        
        # If we're not at the end of the text, try to break at a paragraph or sentence
        if end < len(text):
            # Try to find a paragraph break
            paragraph_break = text.rfind('\n\n', start, end)
            if paragraph_break != -1 and paragraph_break > start + max_chunk_size // 2:
                end = paragraph_break + 2  # Include the paragraph break
            else:
                # Try to find a sentence break
                sentence_break = text.rfind('. ', start, end)
                if sentence_break != -1 and sentence_break > start + max_chunk_size // 2:
                    end = sentence_break + 2  # Include the period and space
        
        # Add the chunk to the list
        chunks.append(text[start:end])
        
        # Move the start position for the next chunk, accounting for overlap
        start = end - overlap if end < len(text) else len(text)
    
    print(f"Document split into {len(chunks)} chunks")
    return chunks

def process_document(bucket, key):
    """Process a document from S3 and split it into chunks"""
    try:
        # Extract text from the document
        document_text = extract_text_from_document(bucket, key)
        
        # Split the document into chunks
        chunks = chunk_document(document_text)
        
        # Prepare chunks for metadata tagging
        chunk_files = []
        for i, chunk in enumerate(chunks):
            # Create a unique ID for the chunk
            chunk_id = f"{key.replace('/', '-')}-chunk-{i}"
            
            # Create a JSON object with the chunk content and metadata
            chunk_data = {
                "chunk_id": chunk_id,
                "content": chunk,
                "source_document": f"s3://{bucket}/{key}",
                "chunk_index": i,
                "total_chunks": len(chunks),
                "created_at": time.time()
            }
            
            # Save the chunk to the processed chunks bucket
            chunk_key = f"chunks/{chunk_id}.json"
            s3.put_object(
                Bucket=processed_chunks_bucket,
                Key=chunk_key,
                Body=json.dumps(chunk_data),
                ContentType='application/json'
            )
            
            chunk_files.append({
                "chunk_id": chunk_id,
                "chunk_key": chunk_key
            })
        
        return {
            "status": "success",
            "document": f"s3://{bucket}/{key}",
            "chunks": chunk_files
        }
    
    except Exception as e:
        print(f"Error processing document: {e}")
        return {
            "status": "error",
            "document": f"s3://{bucket}/{key}",
            "error": str(e)
        }

def handler(event, context):
    """Lambda handler for document processing"""
    print(f"Received event: {json.dumps(event)}")
    
    # Check if the event is from S3
    if 'Records' in event and event['Records'][0].get('eventSource') == 'aws:s3':
        # Process S3 event
        record = event['Records'][0]
        bucket = record['s3']['bucket']['name']
        key = unquote_plus(record['s3']['object']['key'])
        
        result = process_document(bucket, key)
        
        # If processing was successful, trigger the metadata tagger
        if result['status'] == 'success':
            # In a real implementation, we would trigger the metadata tagger Lambda
            # For now, we'll just return the result
            pass
        
        return result
    
    # Handle direct invocation
    elif 'bucket' in event and 'key' in event:
        bucket = event['bucket']
        key = event['key']
        
        return process_document(bucket, key)
    
    else:
        return {
            "status": "error",
            "error": "Invalid event format"
        }
