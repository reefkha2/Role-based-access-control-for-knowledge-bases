#!/usr/bin/env python3

import json
import boto3
import os
import sys

def add_metadata_to_chunk(bucket_name, chunk_key, metadata):
    """Add metadata to a chunk"""
    try:
        # Create S3 client
        s3 = boto3.client('s3')
        
        # Get the chunk from S3
        response = s3.get_object(Bucket=bucket_name, Key=chunk_key)
        chunk_data = json.loads(response['Body'].read().decode('utf-8'))
        
        # Add metadata to the chunk
        chunk_data['metadata'] = metadata
        
        # Save the updated chunk back to S3
        s3.put_object(
            Bucket=bucket_name,
            Key=chunk_key,
            Body=json.dumps(chunk_data),
            ContentType='application/json'
        )
        
        print(f"Successfully added metadata to {chunk_key}")
        return True
    
    except Exception as e:
        print(f"Error adding metadata to chunk: {e}")
        return False

def main():
    # Check if config file exists
    if not os.path.exists('securekb_config.json'):
        print("Error: securekb_config.json not found. Please run deploy_with_cli.sh first.")
        sys.exit(1)
    
    # Load configuration
    with open('securekb_config.json', 'r') as f:
        config = json.load(f)
    
    # Get processed chunks bucket name
    bucket_name = config.get('processed_chunks_bucket')
    if not bucket_name:
        print("Error: processed_chunks_bucket not found in configuration.")
        sys.exit(1)
    
    # Define metadata for each chunk
    chunk_metadata = {
        # Sales Report
        "chunks/documents-sales_report.md-chunk-0.json": {
            "departments": ["sales", "executive"],
            "sensitivity": "internal"
        },
        "chunks/documents-sales_report.md-chunk-1.json": {
            "departments": ["sales"],
            "sensitivity": "confidential"
        },
        
        # HR Policies
        "chunks/documents-hr_policies.md-chunk-0.json": {
            "departments": ["hr", "public"],
            "sensitivity": "public"
        },
        "chunks/documents-hr_policies.md-chunk-1.json": {
            "departments": ["hr", "executive"],
            "sensitivity": "confidential"
        },
        
        # Financial Report
        "chunks/documents-financial_report.md-chunk-0.json": {
            "departments": ["finance", "executive"],
            "sensitivity": "internal"
        },
        "chunks/documents-financial_report.md-chunk-1.json": {
            "departments": ["finance", "executive"],
            "sensitivity": "restricted"
        },
        
        # Executive Strategy
        "chunks/documents-executive_strategy.md-chunk-0.json": {
            "departments": ["public"],
            "sensitivity": "public"
        },
        "chunks/documents-executive_strategy.md-chunk-1.json": {
            "departments": ["sales", "marketing", "executive"],
            "sensitivity": "internal"
        },
        "chunks/documents-executive_strategy.md-chunk-2.json": {
            "departments": ["executive"],
            "sensitivity": "restricted"
        },
        
        # Public Announcement
        "chunks/documents-public_announcement.md-chunk-0.json": {
            "departments": ["public"],
            "sensitivity": "public"
        },
        "chunks/documents-public_announcement.md-chunk-1.json": {
            "departments": ["public"],
            "sensitivity": "public"
        }
    }
    
    # Add metadata to each chunk
    for chunk_key, metadata in chunk_metadata.items():
        add_metadata_to_chunk(bucket_name, chunk_key, metadata)
    
    print("Finished adding metadata to all chunks.")

if __name__ == "__main__":
    main()
