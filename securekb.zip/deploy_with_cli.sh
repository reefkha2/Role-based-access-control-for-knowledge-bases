#!/bin/bash

# Deploy SecureKB using AWS CLI
echo "Deploying SecureKB using AWS CLI..."

# Set variables
REGION="us-west-2"
STACK_NAME="SecureKB"
DOCUMENT_BUCKET="securekb-documents-$(date +%s)"
PROCESSED_BUCKET="securekb-processed-$(date +%s)"

# Create S3 buckets
echo "Creating S3 buckets..."
aws s3api create-bucket --bucket $DOCUMENT_BUCKET --region $REGION --create-bucket-configuration LocationConstraint=$REGION
aws s3api create-bucket --bucket $PROCESSED_BUCKET --region $REGION --create-bucket-configuration LocationConstraint=$REGION

# Enable versioning on document bucket
aws s3api put-bucket-versioning --bucket $DOCUMENT_BUCKET --versioning-configuration Status=Enabled

# Block public access for both buckets
aws s3api put-public-access-block --bucket $DOCUMENT_BUCKET --public-access-block-configuration "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
aws s3api put-public-access-block --bucket $PROCESSED_BUCKET --public-access-block-configuration "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

# Create Cognito User Pool
echo "Creating Cognito User Pool..."
USER_POOL_ID=$(aws cognito-idp create-user-pool \
  --pool-name SecureKB-UserPool \
  --region $REGION \
  --query 'UserPool.Id' \
  --output text)

echo "User Pool ID: $USER_POOL_ID"

# Create User Pool Client
echo "Creating User Pool Client..."
CLIENT_ID=$(aws cognito-idp create-user-pool-client \
  --user-pool-id $USER_POOL_ID \
  --client-name SecureKB-Client \
  --no-generate-secret \
  --region $REGION \
  --query 'UserPoolClient.ClientId' \
  --output text)

echo "Client ID: $CLIENT_ID"

# Create IAM role for Lambda
echo "Creating IAM role for Lambda..."
ROLE_NAME="SecureKB-Lambda-Role"

# Create trust policy document
cat > trust-policy.json << EOL
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "lambda.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOL

# Create role
ROLE_ARN=$(aws iam create-role \
  --role-name $ROLE_NAME \
  --assume-role-policy-document file://trust-policy.json \
  --query 'Role.Arn' \
  --output text)

echo "Role ARN: $ROLE_ARN"

# Attach policies to the role
aws iam attach-role-policy \
  --role-name $ROLE_NAME \
  --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole

aws iam attach-role-policy \
  --role-name $ROLE_NAME \
  --policy-arn arn:aws:iam::aws:policy/AmazonBedrockFullAccess

# Create S3 access policy
cat > s3-policy.json << EOL
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:ListBucket",
        "s3:DeleteObject"
      ],
      "Resource": [
        "arn:aws:s3:::$DOCUMENT_BUCKET",
        "arn:aws:s3:::$DOCUMENT_BUCKET/*",
        "arn:aws:s3:::$PROCESSED_BUCKET",
        "arn:aws:s3:::$PROCESSED_BUCKET/*"
      ]
    }
  ]
}
EOL

# Create and attach S3 policy
aws iam put-role-policy \
  --role-name $ROLE_NAME \
  --policy-name S3Access \
  --policy-document file://s3-policy.json

# Create Lambda functions
echo "Creating Lambda functions..."

# Prepare Lambda code
mkdir -p lambda_packages

# Document Processor Lambda
echo "Packaging Document Processor Lambda..."
mkdir -p lambda_packages/document_processor
cp src/lambda/document_processor/index.py lambda_packages/document_processor/
cd lambda_packages/document_processor
zip -r ../document_processor.zip .
cd ../..

# Metadata Tagger Lambda
echo "Packaging Metadata Tagger Lambda..."
mkdir -p lambda_packages/metadata_tagger
cp src/lambda/metadata_tagger/index.py lambda_packages/metadata_tagger/
cd lambda_packages/metadata_tagger
zip -r ../metadata_tagger.zip .
cd ../..

# Query Processor Lambda
echo "Packaging Query Processor Lambda..."
mkdir -p lambda_packages/query_processor
cp src/lambda/query_processor/index.py lambda_packages/query_processor/
cd lambda_packages/query_processor
zip -r ../query_processor.zip .
cd ../..

# Wait for IAM role to propagate
echo "Waiting for IAM role to propagate..."
sleep 10

# Create Lambda functions
echo "Creating Document Processor Lambda..."
DOC_PROCESSOR_ARN=$(aws lambda create-function \
  --function-name SecureKB-DocumentProcessor \
  --runtime python3.9 \
  --role $ROLE_ARN \
  --handler index.handler \
  --timeout 300 \
  --memory-size 1024 \
  --zip-file fileb://lambda_packages/document_processor.zip \
  --environment "Variables={PROCESSED_CHUNKS_BUCKET=$PROCESSED_BUCKET}" \
  --region $REGION \
  --query 'FunctionArn' \
  --output text)

echo "Document Processor ARN: $DOC_PROCESSOR_ARN"

echo "Creating Metadata Tagger Lambda..."
METADATA_TAGGER_ARN=$(aws lambda create-function \
  --function-name SecureKB-MetadataTagger \
  --runtime python3.9 \
  --role $ROLE_ARN \
  --handler index.handler \
  --timeout 300 \
  --memory-size 1024 \
  --zip-file fileb://lambda_packages/metadata_tagger.zip \
  --environment "Variables={PROCESSED_CHUNKS_BUCKET=$PROCESSED_BUCKET}" \
  --region $REGION \
  --query 'FunctionArn' \
  --output text)

echo "Metadata Tagger ARN: $METADATA_TAGGER_ARN"

echo "Creating Query Processor Lambda..."
QUERY_PROCESSOR_ARN=$(aws lambda create-function \
  --function-name SecureKB-QueryProcessor \
  --runtime python3.9 \
  --role $ROLE_ARN \
  --handler index.handler \
  --timeout 30 \
  --memory-size 512 \
  --zip-file fileb://lambda_packages/query_processor.zip \
  --region $REGION \
  --query 'FunctionArn' \
  --output text)

echo "Query Processor ARN: $QUERY_PROCESSOR_ARN"

# Create S3 event trigger for Document Processor
echo "Setting up S3 event trigger for Document Processor..."
aws lambda add-permission \
  --function-name SecureKB-DocumentProcessor \
  --statement-id s3-trigger \
  --action lambda:InvokeFunction \
  --principal s3.amazonaws.com \
  --source-arn arn:aws:s3:::$DOCUMENT_BUCKET \
  --region $REGION

# Create S3 notification configuration
cat > notification-config.json << EOL
{
  "LambdaFunctionConfigurations": [
    {
      "LambdaFunctionArn": "$DOC_PROCESSOR_ARN",
      "Events": ["s3:ObjectCreated:*"],
      "Filter": {
        "Key": {
          "FilterRules": [
            {
              "Name": "prefix",
              "Value": "documents/"
            }
          ]
        }
      }
    }
  ]
}
EOL

aws s3api put-bucket-notification-configuration \
  --bucket $DOCUMENT_BUCKET \
  --notification-configuration file://notification-config.json

# Create API Gateway
echo "Creating API Gateway..."
API_ID=$(aws apigateway create-rest-api \
  --name SecureKB-API \
  --description "API for SecureKB" \
  --region $REGION \
  --query 'id' \
  --output text)

echo "API ID: $API_ID"

# Get root resource ID
ROOT_RESOURCE_ID=$(aws apigateway get-resources \
  --rest-api-id $API_ID \
  --region $REGION \
  --query 'items[0].id' \
  --output text)

# Create query resource
QUERY_RESOURCE_ID=$(aws apigateway create-resource \
  --rest-api-id $API_ID \
  --parent-id $ROOT_RESOURCE_ID \
  --path-part "query" \
  --region $REGION \
  --query 'id' \
  --output text)

# Create POST method
aws apigateway put-method \
  --rest-api-id $API_ID \
  --resource-id $QUERY_RESOURCE_ID \
  --http-method POST \
  --authorization-type NONE \
  --region $REGION

# Wait for Lambda function to be fully available
echo "Waiting for Lambda functions to be fully available..."
sleep 10

# Create Lambda integration
aws apigateway put-integration \
  --rest-api-id $API_ID \
  --resource-id $QUERY_RESOURCE_ID \
  --http-method POST \
  --type AWS_PROXY \
  --integration-http-method POST \
  --uri arn:aws:apigateway:$REGION:lambda:path/2015-03-31/functions/$QUERY_PROCESSOR_ARN/invocations \
  --region $REGION

# Add permission for API Gateway to invoke Lambda
aws lambda add-permission \
  --function-name SecureKB-QueryProcessor \
  --statement-id apigateway-test-2 \
  --action lambda:InvokeFunction \
  --principal apigateway.amazonaws.com \
  --source-arn "arn:aws:execute-api:$REGION:$(aws sts get-caller-identity --query 'Account' --output text):$API_ID/*/POST/query" \
  --region $REGION

# Deploy API
aws apigateway create-deployment \
  --rest-api-id $API_ID \
  --stage-name prod \
  --region $REGION

# Get API URL
API_URL="https://$API_ID.execute-api.$REGION.amazonaws.com/prod"
echo "API URL: $API_URL"

# Save configuration
echo "Saving configuration..."
cat > securekb_config.json << EOL
{
  "document_bucket": "$DOCUMENT_BUCKET",
  "processed_chunks_bucket": "$PROCESSED_BUCKET",
  "user_pool_id": "$USER_POOL_ID",
  "user_pool_client_id": "$CLIENT_ID",
  "api_url": "$API_URL",
  "document_processor_arn": "$DOC_PROCESSOR_ARN",
  "metadata_tagger_arn": "$METADATA_TAGGER_ARN",
  "query_processor_arn": "$QUERY_PROCESSOR_ARN"
}
EOL

echo "Configuration saved to securekb_config.json"
echo "Deployment completed successfully!"

# Clean up temporary files
rm -f trust-policy.json s3-policy.json notification-config.json
