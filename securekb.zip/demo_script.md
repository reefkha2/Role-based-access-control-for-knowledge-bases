# SecureKB Demo Script

## Introduction (1 minute)

Hello, I'm [Your Name], and today I'll be demonstrating SecureKB, a secure knowledge base solution with role-based access control at the chunk level.

The key innovation of SecureKB is its ability to handle documents with mixed content, where different parts of the same document may have different access requirements. Instead of restricting access at the document level, SecureKB implements access control at the chunk level, allowing for more granular security.

## Architecture Overview (2 minutes)

Let me start by explaining the architecture of SecureKB:

[Show architecture diagram]

The system consists of several key components:
1. Document Processor Lambda: Splits documents into chunks
2. Metadata Tagger Lambda: Uses Amazon Bedrock to classify chunks with department and sensitivity metadata
3. Query Processor Lambda: Filters query results based on user's role and clearance level
4. S3 Buckets: Store original documents and processed chunks
5. Cognito User Pool: Manages users and their attributes (department, clearance level)
6. API Gateway: Provides secure access to the query endpoint

## Document Processing Flow (2 minutes)

Let me walk you through how documents are processed:

1. A user uploads a document to the Document Bucket
2. This triggers the Document Processor Lambda, which splits the document into chunks
3. Each chunk is sent to the Metadata Tagger Lambda
4. The Metadata Tagger uses Amazon Bedrock to classify each chunk with:
   - Department tags (e.g., sales, hr, finance)
   - Sensitivity level (e.g., public, internal, confidential)
5. The classified chunks are stored in the Processed Chunks Bucket

## Query Flow (2 minutes)

When a user queries the knowledge base:

1. The user authenticates through Cognito, which provides their department and clearance level
2. The query is sent to the API Gateway
3. The Query Processor Lambda receives the query and user attributes
4. It generates a filter expression based on the user's department and clearance level
5. Only chunks that match the filter are considered for the query
6. The filtered results are returned to the user

## Demo: Different User Roles (3 minutes)

Let me demonstrate how different users see different results for the same query.

[Show test_query.py script]

I'll run the same query "What are our financial projections?" with different user roles:

1. Sales User (department: sales, clearance: internal)
```bash
python test_query.py --department sales --clearance internal --query "What are our financial projections?"
```
[Show results - only basic financial information visible]

2. Finance User (department: finance, clearance: confidential)
```bash
python test_query.py --department finance --clearance confidential --query "What are our financial projections?"
```
[Show results - detailed financial information visible]

3. Executive User (department: executive, clearance: restricted)
```bash
python test_query.py --department executive --clearance restricted --query "What are our financial projections?"
```
[Show results - all financial information including acquisition plans visible]

As you can see, each user receives different information based on their department and clearance level, even though they're all querying the same knowledge base.

## Conclusion and Next Steps (1 minute)

SecureKB demonstrates how we can implement granular access control in knowledge bases, allowing organizations to maintain a single source of truth while ensuring appropriate access controls.

Future enhancements could include:
- A web UI for document upload and querying
- More sophisticated document chunking strategies
- Support for more document formats
- Audit logging for access tracking
- Document versioning and history

Thank you for watching this demonstration of SecureKB!
