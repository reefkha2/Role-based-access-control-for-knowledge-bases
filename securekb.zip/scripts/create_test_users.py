#!/usr/bin/env python3

import boto3
import argparse
import json
import os
import sys
import uuid
import time

def create_test_users(user_pool_id, user_pool_client_id):
    """Create test users with different roles in Cognito"""
    
    # Initialize Cognito client
    cognito = boto3.client('cognito-idp')
    
    # Define test users with different roles
    test_users = [
        {
            "username": f"sales-user-{int(time.time())}",
            "email": f"sales-user-{int(time.time())}@example.com",
            "given_name": "Sales",
            "family_name": "User",
            "password": "Test@password123",
            "department": "sales",
            "clearance_level": "internal"
        },
        {
            "username": f"hr-user-{int(time.time())}",
            "email": f"hr-user-{int(time.time())}@example.com",
            "given_name": "HR",
            "family_name": "User",
            "password": "Test@password123",
            "department": "hr",
            "clearance_level": "internal"
        },
        {
            "username": f"finance-user-{int(time.time())}",
            "email": f"finance-user-{int(time.time())}@example.com",
            "given_name": "Finance",
            "family_name": "User",
            "password": "Test@password123",
            "department": "finance",
            "clearance_level": "confidential"
        },
        {
            "username": f"executive-user-{int(time.time())}",
            "email": f"executive-user-{int(time.time())}@example.com",
            "given_name": "Executive",
            "family_name": "User",
            "password": "Test@password123",
            "department": "executive",
            "clearance_level": "restricted"
        },
        {
            "username": f"public-user-{int(time.time())}",
            "email": f"public-user-{int(time.time())}@example.com",
            "given_name": "Public",
            "family_name": "User",
            "password": "Test@password123",
            "department": "public",
            "clearance_level": "public"
        }
    ]
    
    created_users = []
    
    for user in test_users:
        try:
            # Create the user in Cognito
            response = cognito.admin_create_user(
                UserPoolId=user_pool_id,
                Username=user["username"],
                UserAttributes=[
                    {"Name": "email", "Value": user["email"]},
                    {"Name": "email_verified", "Value": "true"},
                    {"Name": "given_name", "Value": user["given_name"]},
                    {"Name": "family_name", "Value": user["family_name"]},
                    {"Name": "custom:department", "Value": user["department"]},
                    {"Name": "custom:clearanceLevel", "Value": user["clearance_level"]}
                ],
                TemporaryPassword=user["password"],
                MessageAction="SUPPRESS"
            )
            
            # Set the permanent password
            cognito.admin_set_user_password(
                UserPoolId=user_pool_id,
                Username=user["username"],
                Password=user["password"],
                Permanent=True
            )
            
            print(f"Created user: {user['username']} with role: {user['department']}, clearance: {user['clearance_level']}")
            
            created_users.append({
                "username": user["username"],
                "password": user["password"],
                "department": user["department"],
                "clearance_level": user["clearance_level"]
            })
            
        except Exception as e:
            print(f"Error creating user {user['username']}: {e}")
    
    # Save user credentials to a file
    with open("test_users.json", "w") as f:
        json.dump(created_users, f, indent=2)
    
    print(f"\nCreated {len(created_users)} test users. Credentials saved to test_users.json")
    
    return created_users

def main():
    parser = argparse.ArgumentParser(description="Create test users with different roles in Cognito")
    parser.add_argument("--user-pool-id", required=True, help="Cognito User Pool ID")
    parser.add_argument("--client-id", required=True, help="Cognito User Pool Client ID")
    
    args = parser.parse_args()
    
    create_test_users(args.user_pool_id, args.client_id)

if __name__ == "__main__":
    main()
