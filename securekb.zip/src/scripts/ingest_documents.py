#!/usr/bin/env python3

import boto3
import argparse
import json
import time
import os

def ingest_documents(knowledge_base_id, data_source_id, document_bucket, processed_bucket, region):
    """Ingest documents into a Bedrock Knowledge Base"""
    
    # Initialize clients
    bedrock = boto3.client('bedrock', region_name=region)
    s3 = boto3.client('s3')
    lambda_client = boto3.client('lambda', region_name=region)
    
    # List documents in the document bucket
    response = s3.list_objects_v2(Bucket=document_bucket, Prefix="documents/")
    
    if 'Contents' not in response:
        print(f"No documents found in s3://{document_bucket}/documents/")
        return
    
    # Process each document
    for obj in response['Contents']:
        key = obj['Key']
        if key.endswith('/'):
            continue
        
        print(f"Processing document: s3://{document_bucket}/{key}")
        
        # Invoke the Document Processor Lambda
        doc_processor_response = lambda_client.invoke(
            FunctionName="SecureKbStack-DocumentProcessor",
            InvocationType="RequestResponse",
            Payload=json.dumps({
                "bucket": document_bucket,
                "key": key
            })
        )
        
        # Parse the response
        doc_processor_result = json.loads(doc_processor_response['Payload'].read().decode())
        
        if doc_processor_result['status'] != 'success':
            print(f"Error processing document: {doc_processor_result.get('error', 'Unknown error')}")
            continue
        
        # Process each chunk
        for chunk in doc_processor_result['chunks']:
            # Invoke the Metadata Tagger Lambda
            tagger_response = lambda_client.invoke(
                FunctionName="SecureKbStack-MetadataTagger",
                InvocationType="RequestResponse",
                Payload=json.dumps({
                    "chunk_key": chunk['chunk_key']
                })
            )
            
            # Parse the response
            tagger_result = json.loads(tagger_response['Payload'].read().decode())
            
            if tagger_result['status'] != 'success':
                print(f"Error tagging chunk {chunk['chunk_id']}: {tagger_result.get('error', 'Unknown error')}")
                continue
            
            print(f"Tagged chunk {chunk['chunk_id']} with metadata: {tagger_result['metadata']}")
            
            # Get the tagged chunk from S3
            chunk_response = s3.get_object(
                Bucket=processed_bucket,
                Key=chunk['chunk_key']
            )
            
            chunk_data = json.loads(chunk_response['Body'].read().decode())
            
            # Create a file for ingestion
            ingestion_key = f"ingestion/{chunk['chunk_id']}.txt"
            
            # Add metadata as special markers for the Knowledge Base
            metadata = {
                "departments": chunk_data['metadata']['departments'],
                "sensitivity": chunk_data['metadata']['sensitivity']
            }
            
            # Upload the chunk content with metadata
            s3.put_object(
                Bucket=document_bucket,
                Key=ingestion_key,
                Body=chunk_data['content'],
                Metadata={
                    "departments": json.dumps(metadata['departments']),
                    "sensitivity": metadata['sensitivity']
                }
            )
            
            print(f"Uploaded chunk for ingestion: s3://{document_bucket}/{ingestion_key}")
    
    # Start the ingestion job
    response = bedrock.start_ingestion_job(
        knowledgeBaseId=knowledge_base_id,
        dataSourceId=data_source_id
    )
    
    ingestion_job_id = response['ingestionJob']['ingestionJobId']
    print(f"Started ingestion job: {ingestion_job_id}")
    
    # Wait for the ingestion job to complete
    print("Waiting for ingestion job to complete...")
    while True:
        response = bedrock.get_ingestion_job(
            knowledgeBaseId=knowledge_base_id,
            dataSourceId=data_source_id,
            ingestionJobId=ingestion_job_id
        )
        
        status = response['ingestionJob']['status']
        print(f"Ingestion job status: {status}")
        
        if status == "COMPLETE":
            break
        elif status in ["FAILED", "STOPPED"]:
            raise Exception(f"Ingestion job failed with status: {status}")
        
        time.sleep(30)
    
    print("Document ingestion completed successfully!")

def main():
    parser = argparse.ArgumentParser(description="Ingest documents into a Bedrock Knowledge Base")
    parser.add_argument("--knowledge-base-id", required=True, help="Knowledge Base ID")
    parser.add_argument("--data-source-id", required=True, help="Data Source ID")
    parser.add_argument("--document-bucket", required=True, help="S3 bucket containing the documents")
    parser.add_argument("--processed-bucket", required=True, help="S3 bucket for processed chunks")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    
    args = parser.parse_args()
    
    ingest_documents(
        args.knowledge_base_id,
        args.data_source_id,
        args.document_bucket,
        args.processed_bucket,
        args.region
    )

if __name__ == "__main__":
    main()
