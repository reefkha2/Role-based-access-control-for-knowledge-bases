#!/usr/bin/env python3

import boto3
import argparse
import json
import time

def create_knowledge_base(name, role_arn, data_source_bucket, region):
    """Create a Bedrock Knowledge Base with metadata configuration"""
    
    # Initialize Bedrock client
    bedrock = boto3.client('bedrock', region_name=region)
    
    # Create the Knowledge Base
    response = bedrock.create_knowledge_base(
        name=name,
        roleArn=role_arn,
        knowledgeBaseConfiguration={
            "type": "VECTOR",
            "vectorKnowledgeBaseConfiguration": {
                "embeddingModelArn": f"arn:aws:bedrock:{region}::foundation-model/amazon.titan-embed-text-v1"
            }
        }
    )
    
    knowledge_base_id = response['knowledgeBase']['knowledgeBaseId']
    print(f"Created Knowledge Base: {knowledge_base_id}")
    
    # Wait for the Knowledge Base to be active
    print("Waiting for Knowledge Base to be active...")
    while True:
        response = bedrock.get_knowledge_base(knowledgeBaseId=knowledge_base_id)
        status = response['knowledgeBase']['status']
        print(f"Knowledge Base status: {status}")
        
        if status == "ACTIVE":
            break
        elif status in ["FAILED", "DELETING", "DELETED"]:
            raise Exception(f"Knowledge Base creation failed with status: {status}")
        
        time.sleep(10)
    
    # Create a data source with metadata configuration
    response = bedrock.create_data_source(
        knowledgeBaseId=knowledge_base_id,
        name=f"{name}-data-source",
        dataSourceConfiguration={
            "type": "S3",
            "s3Configuration": {
                "bucketArn": f"arn:aws:s3:::{data_source_bucket}"
            }
        },
        vectorIngestionConfiguration={
            "chunkingConfiguration": {
                "chunkingStrategy": "FIXED_SIZE",
                "fixedSizeChunkingConfiguration": {
                    "maxTokens": 300,
                    "overlapPercentage": 10
                }
            },
            "documentProcessingConfiguration": {
                "textractConfiguration": {}
            },
            "customMetadataFields": [
                {
                    "name": "departments",
                    "type": "STRING_LIST"
                },
                {
                    "name": "sensitivity",
                    "type": "STRING"
                }
            ]
        }
    )
    
    data_source_id = response['dataSource']['dataSourceId']
    print(f"Created Data Source: {data_source_id}")
    
    # Return the Knowledge Base and Data Source IDs
    return {
        "knowledge_base_id": knowledge_base_id,
        "data_source_id": data_source_id
    }

def main():
    parser = argparse.ArgumentParser(description="Create a Bedrock Knowledge Base with metadata configuration")
    parser.add_argument("--name", required=True, help="Name for the Knowledge Base")
    parser.add_argument("--role-arn", required=True, help="IAM Role ARN for the Knowledge Base")
    parser.add_argument("--data-source-bucket", required=True, help="S3 bucket for the data source")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    
    args = parser.parse_args()
    
    result = create_knowledge_base(args.name, args.role_arn, args.data_source_bucket, args.region)
    
    # Save the IDs to a file
    with open("knowledge_base_config.json", "w") as f:
        json.dump(result, f, indent=2)
    
    print(f"Knowledge Base configuration saved to knowledge_base_config.json")

if __name__ == "__main__":
    main()
