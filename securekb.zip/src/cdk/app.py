#!/usr/bin/env python3

import os
from aws_cdk import App, Environment
from secure_kb_stack import SecureKbStack
from knowledge_base_stack import KnowledgeBaseStack

app = App()

# Define the AWS environment
env = Environment(
    account=os.environ.get("CDK_DEFAULT_ACCOUNT", ""),
    region=os.environ.get("CDK_DEFAULT_REGION", "us-west-2")  # Updated to match your region
)

# Create the SecureKB stack
secure_kb_stack = SecureKbStack(app, "SecureKbStack", env=env)

# Create the Knowledge Base stack
knowledge_base_stack = KnowledgeBaseStack(app, "KnowledgeBaseStack", env=env)

app.synth()
