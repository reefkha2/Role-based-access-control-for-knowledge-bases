from aws_cdk import (
    Stack,
    aws_s3 as s3,
    aws_cognito as cognito,
    aws_lambda as lambda_,
    aws_apigateway as apigateway,
    aws_iam as iam,
    RemovalPolicy,
    Duration,
    CfnOutput
)
from constructs import Construct

class SecureKbStack(Stack):
    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # S3 bucket for document storage
        document_bucket = s3.Bucket(
            self, "DocumentBucket",
            removal_policy=RemovalPolicy.RETAIN,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            encryption=s3.BucketEncryption.S3_MANAGED,
            versioned=True,
            lifecycle_rules=[
                s3.LifecycleRule(
                    id="DeleteOldVersions",
                    enabled=True,
                    noncurrent_version_expiration=Duration.days(30)
                )
            ]
        )

        # S3 bucket for processed chunks
        processed_chunks_bucket = s3.Bucket(
            self, "ProcessedChunksBucket",
            removal_policy=RemovalPolicy.RETAIN,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            encryption=s3.BucketEncryption.S3_MANAGED
        )

        # Cognito User Pool using CfnUserPool for more direct control
        user_pool = cognito.CfnUserPool(
            self, "SecureKbUserPool",
            auto_verified_attributes=["email"],
            username_attributes=["email"],
            policies=cognito.CfnUserPool.PoliciesProperty(
                password_policy=cognito.CfnUserPool.PasswordPolicyProperty(
                    minimum_length=12,
                    require_lowercase=True,
                    require_uppercase=True,
                    require_numbers=True,
                    require_symbols=True
                )
            ),
            schema=[
                cognito.CfnUserPool.SchemaAttributeProperty(
                    name="email",
                    required=True,
                    mutable=True
                ),
                cognito.CfnUserPool.SchemaAttributeProperty(
                    name="given_name",
                    required=True,
                    mutable=True
                ),
                cognito.CfnUserPool.SchemaAttributeProperty(
                    name="family_name",
                    required=True,
                    mutable=True
                ),
                cognito.CfnUserPool.SchemaAttributeProperty(
                    name="department",
                    required=False,
                    mutable=True
                ),
                cognito.CfnUserPool.SchemaAttributeProperty(
                    name="clearanceLevel",
                    required=False,
                    mutable=True
                )
            ],
            account_recovery_setting=cognito.CfnUserPool.AccountRecoverySettingProperty(
                recovery_mechanisms=[
                    cognito.CfnUserPool.RecoveryOptionProperty(
                        name="verified_email",
                        priority=1
                    )
                ]
            )
        )

        # Cognito User Pool Client
        user_pool_client = cognito.CfnUserPoolClient(
            self, "SecureKbUserPoolClient",
            user_pool_id=user_pool.ref,
            allowed_o_auth_flows=["implicit"],
            allowed_o_auth_scopes=["email", "openid", "profile"],
            callback_ur_ls=["http://localhost:3000/callback"],
            explicit_auth_flows=["ALLOW_USER_PASSWORD_AUTH", "ALLOW_USER_SRP_AUTH"],
            generate_secret=False
        )

        # Identity Pool
        identity_pool = cognito.CfnIdentityPool(
            self, "SecureKbIdentityPool",
            allow_unauthenticated_identities=False,
            cognito_identity_providers=[
                cognito.CfnIdentityPool.CognitoIdentityProviderProperty(
                    client_id=user_pool_client.ref,
                    provider_name=f"cognito-idp.{self.region}.amazonaws.com/{user_pool.ref}"
                )
            ]
        )

        # IAM role for authenticated users
        authenticated_role = iam.Role(
            self, "AuthenticatedRole",
            assumed_by=iam.FederatedPrincipal(
                "cognito-identity.amazonaws.com",
                conditions={
                    "StringEquals": {
                        "cognito-identity.amazonaws.com:aud": identity_pool.ref
                    },
                    "ForAnyValue:StringLike": {
                        "cognito-identity.amazonaws.com:amr": "authenticated"
                    }
                },
                assume_role_action="sts:AssumeRoleWithWebIdentity"
            )
        )

        # Attach role to identity pool
        cognito.CfnIdentityPoolRoleAttachment(
            self, "IdentityPoolRoleAttachment",
            identity_pool_id=identity_pool.ref,
            roles={
                "authenticated": authenticated_role.role_arn
            }
        )

        # Lambda role with permissions to access Bedrock
        lambda_role = iam.Role(
            self, "LambdaRole",
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
            managed_policies=[
                iam.ManagedPolicy.from_aws_managed_policy_name("service-role/AWSLambdaBasicExecutionRole"),
                iam.ManagedPolicy.from_aws_managed_policy_name("AmazonBedrockFullAccess")
            ]
        )

        # Grant Lambda role access to S3 buckets
        document_bucket.grant_read_write(lambda_role)
        processed_chunks_bucket.grant_read_write(lambda_role)

        # Document Processor Lambda
        document_processor = lambda_.Function(
            self, "DocumentProcessor",
            runtime=lambda_.Runtime.PYTHON_3_9,
            handler="index.handler",
            code=lambda_.Code.from_asset("../lambda/document_processor"),
            timeout=Duration.minutes(5),
            memory_size=1024,
            role=lambda_role,
            environment={
                "PROCESSED_CHUNKS_BUCKET": processed_chunks_bucket.bucket_name
            }
        )

        # Metadata Tagger Lambda
        metadata_tagger = lambda_.Function(
            self, "MetadataTagger",
            runtime=lambda_.Runtime.PYTHON_3_9,
            handler="index.handler",
            code=lambda_.Code.from_asset("../lambda/metadata_tagger"),
            timeout=Duration.minutes(5),
            memory_size=1024,
            role=lambda_role,
            environment={
                "PROCESSED_CHUNKS_BUCKET": processed_chunks_bucket.bucket_name
            }
        )

        # Query Processor Lambda
        query_processor = lambda_.Function(
            self, "QueryProcessor",
            runtime=lambda_.Runtime.PYTHON_3_9,
            handler="index.handler",
            code=lambda_.Code.from_asset("../lambda/query_processor"),
            timeout=Duration.seconds(30),
            memory_size=512,
            role=lambda_role
        )

        # API Gateway
        api = apigateway.RestApi(
            self, "SecureKbApi",
            rest_api_name="SecureKB API",
            description="API for SecureKB",
            default_cors_preflight_options=apigateway.CorsOptions(
                allow_origins=apigateway.Cors.ALL_ORIGINS,
                allow_methods=apigateway.Cors.ALL_METHODS
            )
        )

        # API Gateway Resources
        query_resource = api.root.add_resource("query")
        
        # Add method with Lambda integration (without Cognito authorizer for simplicity)
        query_resource.add_method(
            "POST",
            apigateway.LambdaIntegration(query_processor)
        )

        # Outputs
        CfnOutput(self, "DocumentBucketName", value=document_bucket.bucket_name)
        CfnOutput(self, "ProcessedChunksBucketName", value=processed_chunks_bucket.bucket_name)
        CfnOutput(self, "UserPoolId", value=user_pool.ref)
        CfnOutput(self, "UserPoolClientId", value=user_pool_client.ref)
        CfnOutput(self, "IdentityPoolId", value=identity_pool.ref)
        CfnOutput(self, "ApiUrl", value=api.url)
