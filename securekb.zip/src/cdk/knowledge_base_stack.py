from aws_cdk import (
    Stack,
    aws_iam as iam,
    aws_s3 as s3,
    CfnOutput
)
from constructs import Construct

class KnowledgeBaseStack(Stack):
    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # Create IAM role for Bedrock Knowledge Base
        kb_role = iam.Role(
            self, "KnowledgeBaseRole",
            assumed_by=iam.ServicePrincipal("bedrock.amazonaws.com")
        )

        # Create S3 bucket for Knowledge Base data source
        kb_data_bucket = s3.Bucket(
            self, "KnowledgeBaseDataBucket",
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            encryption=s3.BucketEncryption.S3_MANAGED,
            versioned=True
        )

        # Grant permissions to the Knowledge Base role
        kb_data_bucket.grant_read(kb_role)

        # Output the bucket name and role ARN
        CfnOutput(self, "KnowledgeBaseDataBucketName", value=kb_data_bucket.bucket_name)
        CfnOutput(self, "KnowledgeBaseRoleArn", value=kb_role.role_arn)
