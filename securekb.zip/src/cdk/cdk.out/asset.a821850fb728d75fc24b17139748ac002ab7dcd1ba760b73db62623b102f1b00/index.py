import json
import boto3
import os
import time
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize clients
bedrock = boto3.client('bedrock')
bedrock_agent_runtime = boto3.client('bedrock-agent-runtime')
cloudwatch = boto3.client('cloudwatch')

def extract_user_role(event):
    """Extract user role information from the event"""
    try:
        # In a real implementation, we would extract this from Cognito claims
        # For this demo, we'll get it from the request body
        
        if 'body' in event:
            # API Gateway event format
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
            user_info = body.get('user_info', {})
        else:
            # Direct invocation
            user_info = event.get('user_info', {})
        
        # Extract departments and clearance level
        departments = user_info.get('departments', ['public'])
        clearance_level = user_info.get('clearance_level', 'public')
        
        # Ensure departments is a list
        if isinstance(departments, str):
            departments = [departments]
        
        return {
            "departments": departments,
            "clearance_level": clearance_level
        }
    
    except Exception as e:
        logger.error(f"Error extracting user role: {e}")
        # Default to public access
        return {
            "departments": ["public"],
            "clearance_level": "public"
        }

def generate_filter_expression(user_role):
    """Generate filter expression based on user role"""
    try:
        departments = user_role['departments']
        clearance_level = user_role['clearance_level']
        
        # Define clearance levels and their hierarchy
        clearance_hierarchy = {
            "public": ["public"],
            "internal": ["public", "internal"],
            "confidential": ["public", "internal", "confidential"],
            "restricted": ["public", "internal", "confidential", "restricted"]
        }
        
        # Get allowed sensitivity levels based on user's clearance
        allowed_sensitivity = clearance_hierarchy.get(clearance_level, ["public"])
        
        # Create filter expression
        filter_expression = {
            "andAll": [
                {
                    "listContains": {
                        "key": "metadata.departments",
                        "value": departments[0]  # Start with the first department
                    }
                },
                {
                    "in": {
                        "key": "metadata.sensitivity",
                        "value": allowed_sensitivity
                    }
                }
            ]
        }
        
        # If user has multiple departments, add them with OR logic
        if len(departments) > 1:
            department_filters = []
            for dept in departments:
                department_filters.append({
                    "listContains": {
                        "key": "metadata.departments",
                        "value": dept
                    }
                })
            
            # Replace the first filter with an OR of all departments
            filter_expression["andAll"][0] = {
                "orAll": department_filters
            }
        
        logger.info(f"Generated filter expression: {json.dumps(filter_expression)}")
        return filter_expression
    
    except Exception as e:
        logger.error(f"Error generating filter expression: {e}")
        # Default to public access only
        return {
            "equals": {
                "key": "metadata.sensitivity",
                "value": "public"
            }
        }

def query_knowledge_base(query_text, filter_expression, knowledge_base_id):
    """Query the knowledge base with filters"""
    try:
        logger.info(f"Querying knowledge base: {knowledge_base_id}")
        logger.info(f"Query text: {query_text}")
        
        # Call Bedrock Knowledge Base API
        response = bedrock_agent_runtime.retrieve(
            knowledgeBaseId=knowledge_base_id,
            retrievalQuery={
                "text": query_text
            },
            retrievalConfiguration={
                "vectorSearchConfiguration": {
                    "filter": filter_expression,
                    "numberOfResults": 5
                }
            }
        )
        
        # Extract and format results
        results = []
        for result in response.get('retrievalResults', []):
            content = result.get('content', {}).get('text', '')
            metadata = result.get('metadata', {})
            location = result.get('location', {}).get('type', '')
            score = result.get('score', 0)
            
            results.append({
                "content": content,
                "metadata": metadata,
                "location": location,
                "score": score
            })
        
        return {
            "status": "success",
            "results": results
        }
    
    except Exception as e:
        logger.error(f"Error querying knowledge base: {e}")
        return {
            "status": "error",
            "error": str(e)
        }

def log_access(user_role, query_text, filter_expression, results_count):
    """Log access for audit purposes"""
    try:
        # In a real implementation, we would log to CloudWatch Logs or a database
        logger.info(f"Access log: User with departments {user_role['departments']} and clearance {user_role['clearance_level']} queried: {query_text}")
        logger.info(f"Filter applied: {json.dumps(filter_expression)}")
        logger.info(f"Results returned: {results_count}")
        
        # Publish metrics
        cloudwatch.put_metric_data(
            Namespace='SecureKB',
            MetricData=[
                {
                    'MetricName': 'QueryCount',
                    'Value': 1,
                    'Unit': 'Count',
                    'Dimensions': [
                        {
                            'Name': 'Department',
                            'Value': user_role['departments'][0]
                        },
                        {
                            'Name': 'ClearanceLevel',
                            'Value': user_role['clearance_level']
                        }
                    ]
                },
                {
                    'MetricName': 'ResultsCount',
                    'Value': results_count,
                    'Unit': 'Count'
                }
            ]
        )
    
    except Exception as e:
        logger.error(f"Error logging access: {e}")

def handler(event, context):
    """Lambda handler for query processing"""
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        # Extract query text
        if 'body' in event:
            # API Gateway event format
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
            query_text = body.get('query', '')
            knowledge_base_id = body.get('knowledge_base_id', os.environ.get('KNOWLEDGE_BASE_ID', ''))
        else:
            # Direct invocation
            query_text = event.get('query', '')
            knowledge_base_id = event.get('knowledge_base_id', os.environ.get('KNOWLEDGE_BASE_ID', ''))
        
        # Extract user role
        user_role = extract_user_role(event)
        
        # Generate filter expression
        filter_expression = generate_filter_expression(user_role)
        
        # Query the knowledge base
        query_result = query_knowledge_base(query_text, filter_expression, knowledge_base_id)
        
        # Log access
        results_count = len(query_result.get('results', [])) if query_result.get('status') == 'success' else 0
        log_access(user_role, query_text, filter_expression, results_count)
        
        # Return the result
        return {
            "statusCode": 200 if query_result.get('status') == 'success' else 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps(query_result)
        }
    
    except Exception as e:
        logger.error(f"Error processing query: {e}")
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps({
                "status": "error",
                "error": str(e)
            })
        }
