#!/usr/bin/env python3

import json
import boto3
import os
import sys
import random
import string

def generate_password():
    """Generate a strong random password"""
    # Define character sets
    lowercase = string.ascii_lowercase
    uppercase = string.ascii_uppercase
    digits = string.digits
    special = "!@#$%^&*()_+-=[]{}|;:,.<>?"
    
    # Ensure at least one character from each set
    password = [
        random.choice(lowercase),
        random.choice(uppercase),
        random.choice(digits),
        random.choice(special)
    ]
    
    # Add more random characters to reach desired length (12)
    all_chars = lowercase + uppercase + digits + special
    password.extend(random.choice(all_chars) for _ in range(8))
    
    # Shuffle the password characters
    random.shuffle(password)
    
    # Convert list to string
    return ''.join(password)

def create_test_users(user_pool_id):
    """Create test users with different roles"""
    try:
        # Create Cognito client
        cognito = boto3.client('cognito-idp')
        
        # Define test users
        test_users = [
            {
                "username": "sales_user",
                "email": "sales@example.com",
                "given_name": "Sales",
                "family_name": "User",
                "department": "sales",
                "clearance_level": "internal"
            },
            {
                "username": "hr_user",
                "email": "hr@example.com",
                "given_name": "HR",
                "family_name": "User",
                "department": "hr",
                "clearance_level": "confidential"
            },
            {
                "username": "finance_user",
                "email": "finance@example.com",
                "given_name": "Finance",
                "family_name": "User",
                "department": "finance",
                "clearance_level": "confidential"
            },
            {
                "username": "executive_user",
                "email": "executive@example.com",
                "given_name": "Executive",
                "family_name": "User",
                "department": "executive",
                "clearance_level": "restricted"
            },
            {
                "username": "public_user",
                "email": "public@example.com",
                "given_name": "Public",
                "family_name": "User",
                "department": "public",
                "clearance_level": "public"
            }
        ]
        
        # Create each user
        created_users = []
        for user in test_users:
            # Generate a password
            password = generate_password()
            
            # Create the user
            print(f"Creating user: {user['username']}...")
            cognito.admin_create_user(
                UserPoolId=user_pool_id,
                Username=user['username'],
                UserAttributes=[
                    {'Name': 'email', 'Value': user['email']},
                    {'Name': 'email_verified', 'Value': 'true'},
                    {'Name': 'given_name', 'Value': user['given_name']},
                    {'Name': 'family_name', 'Value': user['family_name']},
                    {'Name': 'custom:department', 'Value': user['department']},
                    {'Name': 'custom:clearanceLevel', 'Value': user['clearance_level']}
                ],
                TemporaryPassword=password,
                MessageAction='SUPPRESS'
            )
            
            # Set the password permanently (skip the force change password step)
            cognito.admin_set_user_password(
                UserPoolId=user_pool_id,
                Username=user['username'],
                Password=password,
                Permanent=True
            )
            
            # Add user to created users list with password
            user_info = user.copy()
            user_info['password'] = password
            created_users.append(user_info)
            
            print(f"Successfully created user: {user['username']}")
        
        # Save user credentials to file
        with open('test_users.json', 'w') as f:
            json.dump(created_users, f, indent=2)
        
        print(f"Created {len(created_users)} test users. Credentials saved to test_users.json")
        return True
    
    except Exception as e:
        print(f"Error creating test users: {e}")
        return False

def main():
    # Check if config file exists
    if not os.path.exists('securekb_config.json'):
        print("Error: securekb_config.json not found. Please run deploy_with_cli.sh first.")
        sys.exit(1)
    
    # Load configuration
    with open('securekb_config.json', 'r') as f:
        config = json.load(f)
    
    # Get user pool ID
    user_pool_id = config.get('user_pool_id')
    if not user_pool_id:
        print("Error: user_pool_id not found in configuration.")
        sys.exit(1)
    
    # Create test users
    print(f"Creating test users in user pool: {user_pool_id}")
    success = create_test_users(user_pool_id)
    
    if success:
        print("Test users created successfully!")
    else:
        print("Failed to create test users.")
        sys.exit(1)

if __name__ == "__main__":
    main()
