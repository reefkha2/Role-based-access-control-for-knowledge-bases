#!/usr/bin/env python3

import json
import boto3
import os
import sys

def create_sample_documents():
    """Create sample documents with mixed content"""
    
    # Sales Report
    sales_report = """# Quarterly Sales Report
    
## Executive Summary
This report provides an overview of our sales performance for Q1 2025. Overall, we have seen a 15% increase in revenue compared to the same period last year.

## Sales Performance by Region
- North America: $2.5M (↑20%)
- Europe: $1.8M (↑12%)
- Asia Pacific: $1.2M (↑18%)
- Latin America: $0.8M (↑5%)

## Competitive Intelligence
Our main competitor, Acme Corp, has recently launched a new product line that directly competes with our premium offerings. Initial market reception appears mixed, with some customers reporting quality issues.

## Customer Acquisition
We've acquired 250 new enterprise customers this quarter, representing a 30% increase over our target.

## Pricing Strategy (CONFIDENTIAL)
We plan to increase our enterprise pricing by 7% next quarter while maintaining current pricing for small business customers. This is expected to increase revenue by approximately $1.2M without significant customer churn.

## Sales Team Reorganization (CONFIDENTIAL)
We will be restructuring the sales team next month to better align with our new product categories. This will involve reassigning 15 team members and hiring 5 new specialized sales representatives.
"""

    # HR Policies
    hr_policies = """# Employee Handbook and HR Policies

## Leave Policy (PUBLIC)
All full-time employees are entitled to:
- 20 days of paid vacation annually
- 10 days of sick leave
- 5 days of personal leave
- Parental leave as per federal regulations

## Performance Review Process (INTERNAL)
Performance reviews are conducted bi-annually in June and December. The review process includes:
1. Self-assessment
2. Manager assessment
3. Peer feedback
4. Goal setting for the next period

## Compensation Structure (CONFIDENTIAL)
Salary bands for each position are determined based on:
- Market research conducted quarterly
- Internal equity considerations
- Performance rating
- Years of experience

The current salary adjustment budget for 2025 is 4.5% of total payroll.

## Organizational Changes (RESTRICTED)
The company is planning to restructure the Product Development department in Q3 2025, which may result in the elimination of 12 positions and the creation of 8 new roles with different skill requirements. This information should not be shared with employees until the official announcement in August.
"""

    # Financial Report
    financial_report = """# Financial Performance Report - Q1 2025

## Revenue Overview (INTERNAL)
Total revenue for Q1 2025 was $15.2M, representing a 18% year-over-year increase.

Revenue breakdown by business line:
- Product A: $5.8M (38%)
- Product B: $4.2M (28%)
- Product C: $3.1M (20%)
- Services: $2.1M (14%)

## Expense Analysis (INTERNAL)
Total expenses for Q1 were $10.8M:
- Cost of goods sold: $4.2M
- R&D: $2.5M
- Sales & Marketing: $2.3M
- G&A: $1.8M

## Profit Margins (CONFIDENTIAL)
Gross margin: 72.4%
Operating margin: 28.9%
Net margin: 22.1%

Product-level margins:
- Product A: 78.5%
- Product B: 68.2%
- Product C: 65.7%
- Services: 82.3%

## Cash Position (CONFIDENTIAL)
Current cash reserves: $28.5M
Burn rate: $1.2M/month
Runway: 23.75 months at current burn rate

## Acquisition Planning (RESTRICTED)
We are currently in preliminary talks to acquire SmallTech Inc. for approximately $45M. The acquisition would be financed through a combination of cash ($15M) and stock ($30M). This would add an estimated $8M in annual revenue and provide access to their specialized AI technology.

Due diligence is currently underway, with a target closing date of September 2025 if we proceed.
"""

    # Executive Strategy
    executive_strategy = """# Executive Strategy Document - 2025-2027

## Vision and Mission (PUBLIC)
Our vision is to become the leading provider of AI-powered business solutions by 2027.

Our mission is to help businesses transform their operations through intelligent automation and data-driven insights.

## Market Analysis (INTERNAL)
The AI solutions market is expected to grow at a CAGR of 35% over the next five years, reaching $125B by 2030. Our current market share is approximately 2.3%, with the potential to reach 5% by 2027 if we execute our strategy effectively.

## Competitive Landscape (INTERNAL)
Key competitors and their strengths:
1. TechGiant - Strong brand, vast resources, but slower innovation cycle
2. AIStartup - Cutting-edge technology, but limited enterprise experience
3. ConsultCorp - Strong enterprise relationships, but weaker technology

## Three-Year Strategy (CONFIDENTIAL)
1. Product Development:
   - Expand our AI model capabilities to support 5 new languages
   - Develop industry-specific solutions for healthcare and finance
   - Increase R&D investment by 35% over three years

2. Go-to-Market:
   - Shift to a vertical-focused sales organization
   - Expand partner ecosystem by 200%
   - Increase marketing spend by 40% with focus on thought leadership

3. Operations:
   - Implement new ERP system in 2026
   - Open new development centers in Eastern Europe and Southeast Asia
   - Reduce COGS by 15% through improved automation

## IPO Planning (RESTRICTED)
We are targeting an IPO in Q2 2027, with a projected valuation of $1.2-1.5B. Key milestones include:
- Reaching $100M ARR by Q4 2026
- Achieving GAAP profitability for at least 2 consecutive quarters
- Building out the executive team with public company experience

## Executive Reorganization (RESTRICTED)
We plan to replace our current CTO in Q3 2025 due to performance concerns and strategic misalignment. We have already engaged a search firm to identify candidates with stronger AI expertise and public company experience.
"""

    # Public Announcement
    public_announcement = """# Press Release: New Product Launch

## FOR IMMEDIATE RELEASE (PUBLIC)

# XYZ Corp Launches Revolutionary AI-Powered Business Analytics Platform

**SEATTLE, WA - June 15, 2025** - XYZ Corp, a leader in business intelligence solutions, today announced the launch of InsightAI, a groundbreaking analytics platform that leverages artificial intelligence to transform how businesses understand and act on their data.

InsightAI enables organizations of all sizes to:
- Automatically discover patterns and anomalies in business data
- Generate natural language explanations of complex trends
- Receive proactive alerts and recommendations
- Create stunning visualizations with simple voice commands

"InsightAI represents the culmination of three years of research and development," said Jane Smith, CEO of XYZ Corp. "We've created a solution that democratizes data analytics, making advanced insights accessible to everyone in an organization, not just data scientists."

Early adopters report significant benefits:
- Acme Inc. reduced reporting time by 75%
- TechStart improved forecast accuracy by 35%
- Global Services identified $2.3M in cost-saving opportunities

InsightAI is available immediately through a subscription model starting at $499 per month for small businesses, with enterprise pricing available for larger organizations.

## About XYZ Corp
Founded in 2020, XYZ Corp is dedicated to making data analytics accessible, actionable, and valuable for organizations worldwide. With offices in Seattle, Boston, and Singapore, XYZ serves over 500 customers across 20 countries.

## Contact
Media Relations
media@xyzcorp.com
(555) 123-4567
"""

    return {
        "sales_report.md": sales_report,
        "hr_policies.md": hr_policies,
        "financial_report.md": financial_report,
        "executive_strategy.md": executive_strategy,
        "public_announcement.md": public_announcement
    }

def upload_documents(bucket_name):
    """Upload sample documents to S3"""
    try:
        # Create S3 client
        s3 = boto3.client('s3')
        
        # Create sample documents
        documents = create_sample_documents()
        
        # Upload each document
        for filename, content in documents.items():
            print(f"Uploading {filename}...")
            s3.put_object(
                Bucket=bucket_name,
                Key=f"documents/{filename}",
                Body=content.encode('utf-8'),
                ContentType='text/markdown'
            )
            print(f"Successfully uploaded {filename}")
        
        print(f"All documents uploaded to s3://{bucket_name}/documents/")
        return True
    
    except Exception as e:
        print(f"Error uploading documents: {e}")
        return False

def main():
    # Check if config file exists
    if not os.path.exists('securekb_config.json'):
        print("Error: securekb_config.json not found. Please run deploy_with_cli.sh first.")
        sys.exit(1)
    
    # Load configuration
    with open('securekb_config.json', 'r') as f:
        config = json.load(f)
    
    # Get document bucket name
    document_bucket = config.get('document_bucket')
    if not document_bucket:
        print("Error: document_bucket not found in configuration.")
        sys.exit(1)
    
    # Upload documents
    print(f"Uploading sample documents to bucket: {document_bucket}")
    success = upload_documents(document_bucket)
    
    if success:
        print("Sample documents uploaded successfully!")
    else:
        print("Failed to upload sample documents.")
        sys.exit(1)

if __name__ == "__main__":
    main()
