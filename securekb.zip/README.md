# Role-based-access-control-for-knowledge-bases
Role-based access control for knowledge bases
